FF
FF
DF
FE
N
N
N
