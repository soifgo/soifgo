Bluetooth Modules HC‑05 & JDY‑31 — Set Baud Rate to 115200
Full English Version (Single‑Block)

------------------------------------------------------------
HC‑05 — Set Baud Rate to 115200
------------------------------------------------------------

Enter AT Mode:
- Hold the KEY/EN button or pin HIGH
- Power the module ON
- LED blinks slowly (AT mode)

Serial Connection:
- TX → RX
- RX → TX
- GND → GND
- Open serial terminal at 38400 baud (AT mode default)

Test Communication:
AT
Expected: OK

Set Baud Rate:
AT+UART=115200,0,0
Expected: OK

Reboot:
- Power cycle the module
- Normal communication now works at 115200 baud


------------------------------------------------------------
JDY‑31‑SPP — Set Baud Rate to 115200
------------------------------------------------------------

Enter Configuration Mode:
If the module has a KEY/EN/AT pin:
- Set the pin HIGH
- Power the module ON
(Some versions enter AT mode automatically)

Serial Connection:
- TX → RX
- RX → TX
- GND → GND
Try default baud rates: 9600, 38400, 115200

Set Baud Rate (Firmware‑Dependent):

Common command:
AT+BAUD8

Alternative command:
AT+SPEED=115200

Test:
AT
Expected: OK

Reboot:
- Power cycle the module
- Communication now works at 115200 baud


------------------------------------------------------------
Quick Reference
------------------------------------------------------------

HC‑05:
AT
AT+UART=115200,0,0

JDY‑31:
AT+BAUD8
or
AT+SPEED=115200




------------------------------------------------------------
TTL TO BLUETOOTH MODULE WIRING (HC‑05 / JDY‑31)
------------------------------------------------------------

        USB‑TTL Adapter                     Bluetooth Module
        ----------------                     ----------------
              5V        ------------------>      5V
              GND       ------------------>      GND

              TX        ------------------>      RX
              RX        ------------------>      TX

(OPTIONAL for AT Mode)
              3.3V      ------------------>      KEY / EN / AT

------------------------------------------------------------
NOTES:
------------------------------------------------------------
- TX of USB‑TTL must connect to RX of Bluetooth module.
- RX of USB‑TTL must connect to TX of Bluetooth module.
- GND must be common between both boards.
- Most HC‑05/JDY‑31 boards accept 5V on VCC but use 3.3V logic internally.
- KEY/EN pin is only needed for entering AT Mode.
- No resistors or level shifters are required for common breakout boards.
- If using a bare module (not breakout), use a 3.3V regulator + level shifter.

------------------------------------------------------------
OPTIONAL LEVEL SHIFTING (IF MODULE IS BARE 3.3V)
------------------------------------------------------------

USB‑TTL TX ----[ 1K ]----+----> Bluetooth RX
                         |
                        [2K]
                         |
                        GND

Bluetooth TX -----------> USB‑TTL RX  (direct OK)

------------------------------------------------------------
END
------------------------------------------------------------

