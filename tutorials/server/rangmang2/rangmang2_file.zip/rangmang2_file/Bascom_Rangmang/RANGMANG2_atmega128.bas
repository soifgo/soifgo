$regfile = "m128def.dat"
$crystal = 110592

$prog &HFF , &HBF , &HCF , &HFF       ' generated. Take care that the chip supports all fuse bytes.

Config Watchdog = 1024
Enable Interrupts
$baud = 1152
Reset Watchdog
Ff:
Dim S , E , I , A As Byte
 Dim Text As String * 254
 Dim Temp As String * 2
  Dim Trig As String * 3
Config Rainbow = 1 , Rb0_len = 256 , Rb0_port = Portg , Rb0_pin = 4
Dim Color(3) As Byte
R Alias Color(_base)
G Alias Color(_base + 1)
B Alias Color(_base + 2)
Rb_selectchannel 0
Rb_clearcolors
Rb_clearstripe
Reset Watchdog
Config Serialin = Buffered , Size = 254 , Bytematch = 13
Reset Watchdog
Clear Serialin
Echo Off

Declare Sub Setpin(byval N As Byte)
Declare Sub Red

'''''''''''''''''''''''''''
Const Pin1 = Varptr(porte) + &H20
Const Pin2 = Varptr(porte) + &H20
Const Pin3 = Varptr(porte) + &H20
Const Pin4 = Varptr(porte) + &H20
Const Pin5 = Varptr(porte) + &H20
Const Pin6 = Varptr(porte) + &H20
Const Pin7 = Varptr(portb) + &H20
Const Pin8 = Varptr(portb) + &H20
Const Pin9 = Varptr(portb) + &H20
Const Pin10 = Varptr(portb) + &H20
Const Pin11 = Varptr(portb) + &H20
Const Pin12 = Varptr(portb) + &H20
Const Pin13 = Varptr(portb) + &H20
Const Pin14 = Varptr(portb) + &H20
Const Pin15 = Varptr(portg) + &H20
Const Pin16 = Varptr(portd) + &H20
Const Pin17 = Varptr(portd) + &H20
Const Pin18 = Varptr(portd) + &H20
Const Pin19 = Varptr(portd) + &H20
Const Pin20 = Varptr(portd) + &H20
Const Pin21 = Varptr(portd) + &H20
Const Pin22 = Varptr(portd) + &H20
Const Pin23 = Varptr(portd) + &H20
Const Pin24 = Varptr(portg) + &H20
Const Pin25 = Varptr(portg) + &H20
Const Pin26 = Varptr(portc) + &H20
Const Pin27 = Varptr(portc) + &H20
Const Pin28 = Varptr(portc) + &H20
Const Pin29 = Varptr(portc) + &H20
Const Pin30 = Varptr(portc) + &H20
Const Pin31 = Varptr(portc) + &H20
Const Pin32 = Varptr(portc) + &H20
Const Pin33 = Varptr(portc) + &H20
Const Pin34 = Varptr(portg) + &H20
Const Pin35 = Varptr(porta) + &H20
Const Pin36 = Varptr(porta) + &H20
Const Pin37 = Varptr(porta) + &H20
Const Pin38 = Varptr(porta) + &H20
Const Pin39 = Varptr(porta) + &H20
Const Pin40 = Varptr(porta) + &H20
Const Pin41 = Varptr(porta) + &H20
Const Pin42 = Varptr(porta) + &H20
Const Pin43 = Varptr(portf) + &H20
Const Pin44 = Varptr(portf) + &H20
Const Pin45 = Varptr(portf) + &H20
Const Pin46 = Varptr(portf) + &H20
Const Pin47 = Varptr(portf) + &H20
Const Pin48 = Varptr(portf) + &H20
Const Pin49 = Varptr(portf) + &H20
Const Pin50 = Varptr(portf) + &H20
''''''''''''''''''''''''''''''''''''''''''

    Dim Ch , K As Byte
   Readeeprom Ch , 1

  Dim Cl , Hexin As Bit
   If Ch > 51 Or Ch < 1 Then Ch = 50


 Do
 Loop
Serial0charmatch:
   Input Text Noecho
If Len(text) > 2 Then Call Red
Return

Sub Red
   Print "t=" ; Text
         Rb_selectchannel 0
         Reset Watchdog
               Hexin = 0
   If Instr(text , "WAIT") > 0 Then
            Print "next"
            Cl = 1
            Hexin = 1
   End If
   If Instr(text , "wait") > 0 Then
            Print "next"
            Cl = 0
                Hexin = 1
   End If
    If Hexin = 0 Then
        If Cl = 1 Then
            For K = 1 To Ch
             Call Setpin(k)
              Rb_clearstripe
            Next
          Cl = 0
        End If
         Dim Lent , Loct , Lentn As Byte
         Lentn = Len(text) - 1
         Lentn = Lentn / 12
         Loct = 0
     For Lent = 1 To Lentn
         Loct = Loct + 2
        Temp = Mid(text , Loct , 2) : A = Hexval(temp)
        Call Setpin(a)
         Loct = Loct + 2
        Temp = Mid(text , Loct , 2) : R = Hexval(temp)
        Loct = Loct + 2
        Temp = Mid(text , Loct , 2) : G = Hexval(temp)
        Loct = Loct + 2
        Temp = Mid(text , Loct , 2) : B = Hexval(temp)
        Loct = Loct + 2
        Temp = Mid(text , Loct , 2) : S = Hexval(temp)
        Loct = Loct + 2
        Temp = Mid(text , Loct , 2) : E = Hexval(temp)
          For I = S To E
             Reset Watchdog
             Rb_setcolor I , Color(1)
          Next
          Rb_send

     Next

      Reset Watchdog

      Print "next"


   End If


   If Instr(text , "CH=") > 0 Then

            Trig = Mid(text , 4 , 2)
             Print "OK CH >" ; Trig
            Ch = Val(trig )

            If Ch > 0 And Ch < 51 Then
               Writeeeprom Ch , 1
               Print "OK CH=" ; Ch
            End If
            trig=""
   End If
End Sub


Sub Setpin(byval N As Byte)
    Select Case N
        Case 1 : Rb_changepin Pin1 , 2
        Case 2 : Rb_changepin Pin2 , 3
        Case 3 : Rb_changepin Pin3 , 4
        Case 4 : Rb_changepin Pin4 , 5
        Case 5 : Rb_changepin Pin5 , 6
        Case 6 : Rb_changepin Pin6 , 7
        Case 7 : Rb_changepin Pin7 , 0
        Case 8 : Rb_changepin Pin8 , 1
        Case 9 : Rb_changepin Pin9 , 2
        Case 10 : Rb_changepin Pin10 , 3
        Case 11 : Rb_changepin Pin11 , 4
        Case 12 : Rb_changepin Pin12 , 5
        Case 13 : Rb_changepin Pin13 , 6
        Case 14 : Rb_changepin Pin14 , 7
        Case 15 : Rb_changepin Pin15 , 3
        Case 16 : Rb_changepin Pin16 , 0
        Case 17 : Rb_changepin Pin17 , 1
        Case 18 : Rb_changepin Pin18 , 2
        Case 19 : Rb_changepin Pin19 , 3
        Case 20 : Rb_changepin Pin20 , 4
        Case 21 : Rb_changepin Pin21 , 5
        Case 22 : Rb_changepin Pin22 , 6
        Case 23 : Rb_changepin Pin23 , 7
        Case 24 : Rb_changepin Pin24 , 0
        Case 25 : Rb_changepin Pin25 , 1
        Case 26 : Rb_changepin Pin26 , 0
        Case 27 : Rb_changepin Pin27 , 1
        Case 28 : Rb_changepin Pin28 , 2
        Case 29 : Rb_changepin Pin29 , 3
        Case 30 : Rb_changepin Pin30 , 4
        Case 31 : Rb_changepin Pin31 , 5
        Case 32 : Rb_changepin Pin32 , 6
        Case 33 : Rb_changepin Pin33 , 7
        Case 34 : Rb_changepin Pin34 , 2
        Case 35 : Rb_changepin Pin35 , 7
        Case 36 : Rb_changepin Pin36 , 6
        Case 37 : Rb_changepin Pin37 , 5
        Case 38 : Rb_changepin Pin38 , 4
        Case 39 : Rb_changepin Pin39 , 3
        Case 40 : Rb_changepin Pin40 , 2
        Case 41 : Rb_changepin Pin41 , 1
        Case 42 : Rb_changepin Pin42 , 0
        Case 43 : Rb_changepin Pin43 , 7
        Case 44 : Rb_changepin Pin44 , 6
        Case 45 : Rb_changepin Pin45 , 5
        Case 46 : Rb_changepin Pin46 , 4
        Case 47 : Rb_changepin Pin47 , 3
        Case 48 : Rb_changepin Pin48 , 2
        Case 49 : Rb_changepin Pin49 , 1
        Case 50 : Rb_changepin Pin50 , 0
    End Select
End Sub