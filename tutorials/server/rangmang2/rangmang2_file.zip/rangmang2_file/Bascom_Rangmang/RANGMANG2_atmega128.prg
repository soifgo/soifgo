FF
BF
CF
FF
N
N
N
