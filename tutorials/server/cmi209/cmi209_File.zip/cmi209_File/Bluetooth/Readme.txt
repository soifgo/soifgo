

# How to set the baud rate of **JDY-31-SPP** and **HC-05** Bluetooth modules to **115200**

## 1) JDY-31-SPP
The **JDY-31-SPP** usually supports changing the UART baud rate using **AT commands** or by entering a configuration mode, depending on the exact firmware version.

### General steps
1. **Power the module in AT/config mode**
   - Some versions require a special pin or startup condition.
   - Check whether your module has an **AT/KEY/EN** pin.

2. **Connect UART**
   - `TX` of module → `RX` of USB-to-Serial
   - `RX` of module → `TX` of USB-to-Serial
   - `GND` common ground
   - Use the correct logic voltage, often **3.3V**.

3. **Open a serial terminal**
   - Set the current baud rate to the module’s default baud rate first.
   - Try common default values like:
     - `9600`
     - `38400`
     - `115200`

4. **Send AT command to change baud rate**
   - The exact command depends on firmware, but commonly it looks like:
     ```txt
     AT+BAUD8
     ```
     or similar.
   - On many Bluetooth modules, the baud selection is encoded as a number:
     - `AT+BAUD1`
     - `AT+BAUD2`
     - ...
     - one of them corresponds to `115200`.

5. **Save and reboot**
   - After changing the setting, power-cycle the module.

### Important note
The **exact AT command syntax is not universal** for JDY modules.  
For your specific JDY-31-SPP version, the baud command may differ. If the module has a datasheet or AT command list, use that as the final reference.

---

## 2) HC-05
The **HC-05** is more well-known and usually can be configured in **AT mode**.

### Default AT mode baud rate
Most HC-05 modules use:
- **38400** baud in AT mode

### Steps to set to 115200
1. **Enter AT mode**
   - Hold the **KEY/EN/boot** pin high before powering on, or press the button if your board has one.
   - The LED usually blinks slowly in AT mode.

2. **Connect UART**
   - Same wiring:
     - `TXD` → `RX`
     - `RXD` → `TX`
     - `GND` → `GND`

3. **Open serial monitor**
   - Set baud rate to `38400`
   - Line ending: often **Both NL & CR** or just **CR+LF**, depending on the terminal

4. **Send the command**
   ```txt
   AT+UART=115200,0,0
   ```

   Meaning:
   - `115200` = baud rate
   - `0` = 1 stop bit
   - `0` = no parity

5. **Expected response**
   ```txt
   OK
   ```

6. **Reboot the module**
   - Disconnect and reconnect power
   - Then use `115200` as the normal communication baud rate

---

## Example for HC-05
If you want to set it to 115200:

```txt
AT
AT+UART=115200,0,0
```

If the module responds:
```txt
OK
```
then it worked.

---

## Troubleshooting
If commands do not work:

- Make sure you are in **AT mode**
- Make sure serial terminal baud is correct
- Use **3.3V logic** if required
- Double-check line endings
- Some HC-05 boards require **AT mode at 38400**, not 9600
- Some JDY-31-SPP modules may have **different AT syntax**

---

## Short summary
- **HC-05**: usually set with  
  ```txt
  AT+UART=115200,0,0
  ```
- **JDY-31-SPP**: baud rate can also usually be changed by AT command, but the exact command depends on the firmware version

