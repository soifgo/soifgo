@echo off
echo Identifying Chip...
@echo off
echo Identifying Chip...
avrdude -c usbasp -p m128 -B 4

if %errorlevel% == 0 (
    echo Chip identified at high speed. Programming at high speed...
    avrdude -c usbasp -p m128 -U flash:w:RANGMAN_atmega128.hex:i -U lfuse:w:0xBE:m -U hfuse:w:0xCF:m -U efuse:w:0xFE:m -B 4
) else (
    echo High speed identification failed. Trying mid speed...
    avrdude -c usbasp -p m128 -B 8
    if %errorlevel% == 0 (
        echo Chip identified at mid speed. Programming at mid speed...
        avrdude -c usbasp -p m128 -U flash:w:RANGMAN_atmega128.hex:i -U lfuse:w:0xFE:m -U hfuse:w:0xCF:m -B 8
    ) else (
        echo Mid speed identification failed. Trying low speed...
        avrdude -c usbasp -p m128 -B 32
        if %errorlevel% == 0 (
            echo Chip identified at low speed. Programming at low speed...
            avrdude -c usbasp -p m128 -U flash:w:RANGMAN_atmega128.hex:i -U lfuse:w:0xFE:m -U hfuse:w:0xCF:m -B 16
        ) else (
            echo All speed attempts failed. Please check connections and try again.
        )
    )
)

pause

