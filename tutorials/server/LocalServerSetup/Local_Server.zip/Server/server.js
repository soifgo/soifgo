const fastify = require('fastify')({ logger: true });
const path = require('path');

fastify.register(require('@fastify/formbody'));

let dataStore = {};

fastify.get('/', (request, reply) => {
  reply.send({ message: 'Welcome to the Fastify server!' });
});

fastify.post('/:dataKey', (request, reply) => {
  const dataKey = request.params.dataKey;
  dataStore[dataKey] = {
    ...dataStore[dataKey],
    ...request.body
  };
  reply.status(200).send({ status: 'success', data: dataStore[dataKey] });
});

fastify.get('/:dataKey', (request, reply) => {
  const dataKey = request.params.dataKey;
  if (dataStore[dataKey]) {
    reply.status(200).send(dataStore[dataKey]);
  } else {
    reply.status(404).send({ status: 'error', message: 'Data not found' });
  }
});

fastify.get('/keys', (request, reply) => {
  const keys = Object.keys(dataStore);
  reply.status(200).send({ keys });
});

fastify.listen({ port: 3000, host: '0.0.0.0' }, (err, address) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  console.log(`Server is running on ${address}`);
});
