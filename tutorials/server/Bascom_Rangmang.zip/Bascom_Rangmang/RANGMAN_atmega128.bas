 ' Saeid Moghadam
' SSMQQMSS@gmail.com
' SoifDesign
' Rangmang ATmega328 � 480 pixels
' 30 inputs
' ADRGBSEM
' A00D00R000G000B000S000E000M000
' A01 TO A98   FOR ADDRESS MODULE   A99 FOR ALL
' IF D00 THEN SOLID COLOR
' R000 TO R255   RED COLOR
' G000 TO G255   GREEN COLOR
' B000 TO B255   BLUE COLOR
' S000 TO S480   RGB STRIP START POSITION FOR COLORED PIXEL
' E000 TO E480   RGB STRIP END POSITION FOR COLORED PIXEL
' M000 TO M098   M000 WITHOUT MEMORY SAVE   M001 SAVE SLOT 1 MEMORY

' IF D01 TO D38   DANCE
' D39   FOR RANDOM SELECT D01 TO D38 DANCE
' R000 TO R250   RED COLOR   R251 TO R255 FOR RANDOM RED COLOR
' G000 TO G250   GREEN COLOR   G251 TO G255 FOR RANDOM GREEN COLOR
' B000 TO B250   BLUE COLOR   B251 TO B255 FOR RANDOM BLUE COLOR
' S000 TO S999   RGB STRIP FIRST DELAY EFFECT (ms)
' E000 TO E999   RGB STRIP SECOND DELAY EFFECT (ms)
' M001 TO M480   SET HOW MANY PIXELS DANCING

' Rangmang ATmega128 � 999 pixels
' 30 inputs
' ADRGBSEM
' A00D00R000G000B000S000E000M000
' A01 TO A98   FOR ADDRESS MODULE   A99 FOR ALL
' IF D00 THEN SOLID COLOR
' R000 TO R255   RED COLOR
' G000 TO G255   GREEN COLOR
' B000 TO B255   BLUE COLOR
' S000 TO S480   RGB STRIP START POSITION FOR COLORED PIXEL
' E000 TO E480   RGB STRIP END POSITION FOR COLORED PIXEL
' M000 TO M098   M000 WITHOUT MEMORY SAVE   M001 SAVE SLOT 1 MEMORY

' IF D01 TO D38   DANCE
' D39   FOR RANDOM SELECT D01 TO D38 DANCE
' R000 TO R250   RED COLOR   R251 TO R255 FOR RANDOM RED COLOR
' G000 TO G250   GREEN COLOR   G251 TO G255 FOR RANDOM GREEN COLOR
' B000 TO B250   BLUE COLOR   B251 TO B255 FOR RANDOM BLUE COLOR
' S000 TO S999   RGB STRIP FIRST DELAY EFFECT (ms)
' E000 TO E999   RGB STRIP SECOND DELAY EFFECT (ms)
' M001 TO M999   SET HOW MANY PIXELS DANCING



$regfile = "m128def.dat"
$crystal = 1105920
$PROG &HFF,&HBE,&HCF,&HFE' generated. Take care that the chip supports all fuse bytes.
$hwstack=40
$swstack=16
$framesize = 32

Reset Watchdog
Dim Ina As Bit                                              'external crystal 11059200
Config Watchdog = 512
 Enable Interrupts
 $baud = 960

Ff:
'----[MAIN]---------------------------------------------------------------------
   Dim Danc , Dan , Dans As Byte
   Dim N , Nd , Ndn , Ns , Nf , Jj , Led , S,ii,I,t As Word
   Dim Ch , Ch0 , A1 , A2 , A3 As Byte
   Dim Text As String * 77
   Dim Trig As String * 6
   Dim Rq(99) , Gq(99) , Bq(99)  As Byte
   Dim  Rgb , Mmr , Mmg , Mmb As Byte
   Dim Tim1 , Tim2 , Tt1 , Tt2 , Ado , Ll, Adss,ADSS2 , Adsm,ADSm2  As Word
   Dim Rr , Gg , Bb As Byte
   Dim Rx , Gx , Bx As Byte
   Dim Chc,nnb  As Bit
   dim nnd,pnd AS WORD
  ''''''''''''''''''''''''''''''''''
  dim xfd,yfd,vfd,bfd as word


   dim memoclr as byte
   Declare Sub memclr                                        ' select first chann
   Declare Sub Chekm
   Declare Sub time1
   Declare Sub time2
   Readeeprom Ch0 , 1
   Readeeprom Dan , 2
   Readeeprom Rr , 3
   Readeeprom Gg , 4
   Readeeprom Bb , 5
   Readeeprom Led , 6
   Readeeprom memoclr , 9
   Readeeprom Tim1 , 10
   Readeeprom Tim2 , 12
   call chekm
   If Ch0 > 98 Or Ch0 <1 Then Ch0 = 1
   If Dan > 99 Then Dan = 0
   If Led >990 Then Led = 990

    if memoclr=0 or memoclr>1 then
      call memclr
      memoclr=1
      writeeeprom memoclr , 9
    end if


   Danc = Dan

   Config Rainbow = 1 , Rb0_len = 999 , Rb0_port = Portf , Rb0_pin = 3
   Dim Color(3) As Byte
   R Alias Color(_base) : G Alias Color(_base + 1) : B Alias Color(_base + 2)
   Rb_selectchannel 0
   Rb_clearcolors
   Rb_clearstripe

   Config Portb.1 = Input
   Ddrb.1 = 0 : Portb.1 = 1
   Reset Watchdog

   For I = 1 To 98
      Mmr = I + 100
      Mmg = I + 200
      Mmb = I + 300

      Readeeprom Rgb , Mmr
      Rq(i) = Rgb
      Readeeprom Rgb , Mmg
      Gq(i) = Rgb
      Readeeprom Rgb , Mmb
      Bq(i) = Rgb
      Reset Watchdog
     If Dan = 0 Then
      If Led > 0 And Led < 99 Then
            Reset Watchdog
            Adss = i*4
            Adss = Adss +396
            R = Rq(i) : G = Gq(i) : B = Bq(i)
           adss2=adss+2
            Readeeprom Adsm , Adss
             Readeeprom Adsm2 , Adss2
            For S = adsm To adsm2
               Reset Watchdog
               Rb_setcolor S , Color(1)
            Next

               Rb_send
      Else
         If Led = 999 Then
            Reset Watchdog
            R = rr : G = gg : B = bb
            Rb_fillstripe Color
         End If
      End If
     End If
   Next

dim error as byte

 Config Serialin = Buffered , Size = 34 , Bytematch = 13
   Reset Watchdog
   Clear Serialin
   '''''''''''''''''''''''''''''dance subs'''''''''
  Declare Sub snak_run_slow
  Declare Sub snak_return_slow
  Declare Sub snak_run_fast
  Declare Sub snak_return_fast
  Declare Sub snak_run_slow_random
  Declare Sub snak_return_slow_random
  Declare Sub snak_run_fast_random
  Declare Sub snak_return_fast_random
  Declare Sub snak_runreturn_slow_random
  Declare Sub half_snak_out_mid_slow
  Declare Sub half_snak_mid_out_slow
  Declare Sub half_half_right_slow
  Declare Sub half_half_left_slow
  Declare Sub star_runreturn_slow
  Declare Sub star_run_slow
  Declare Sub star_return_slow
  Declare Sub star_run_fast
  Declare Sub star_return_fast
  Declare Sub snak_growup_slow
  Declare Sub star_playful
  Declare Sub snak_star_playful
  Declare Sub star_fillers
  declare sub movable_light
  declare sub snak_runreturn_colored
  declare sub star_diamonds_blink_slow
  declare sub star_diamonds_blink_fast
  declare sub star_diamonds_blink_faster
  declare sub disco
  declare sub fillstripe_Color
  declare sub breathing
  declare sub percolate
  declare sub percolate_snak
  declare sub half_percolate_solid
   Echo On
   Dim Pos As Byte
Do
  Main:
   Reset Watchdog
  If Danc > 0 and ina=0 Then Goto Modh
Loop

Serial0charmatch:
Ina = 1
      Input Text
      Clear Serialin
      If Text <> "" Then Goto Red
Return


red:


  Text = Trim(text)
  Text = Ltrim(text)
   Pos = Instr(text , "A")



  Reset Watchdog

   Hh:

   If Instr(text , "CH=") > 0 Then
        Trig = Mid(text , 4 , 2)
          Ch = Val(trig)
      If Ch > 0 And Ch < 99 Then
            Ch0 = Ch
            Writeeeprom Ch0 , 1
            Waitms 1
           Print "address=" ; Ch0
         End If
   End If


 If Pos > 0 Then

     Text = Mid(text , Pos)




         If Instr(text , "A") > 0 Then
            Trig = Mid(text , 2 , 2)
           Ch = Val(trig)

         End If


         If Ch = Ch0 Or Ch = 99 Then

           If Instr(text , "D") > 0 Then
              Trig = Mid(text , 5 , 2)

              Danc = Val(trig)
              Dan = Danc
           End If

             If Danc > 99 Then Dan = 0
              Writeeeprom Dan , 2
              Waitms 1
                       If Instr(text , "R") > 0 Then
                          Trig = Mid(text , 8 , 3)
                          R = Val(trig)
                          Rr = R
                       End If
                       If Instr(text , "G") > 0 Then
                          Trig = Mid(text , 12 , 3)
                          G = Val(trig)
                          Gg = G
                       End If

                       If Instr(text , "B") > 0 Then
                          Trig = Mid(text , 16 , 3)
                          B = Val(trig)
                          Bb = B
                       End If
                       If Instr(text , "M") > 0 Then
                          Trig = Mid(text , 28 , 3)
                          Led = Val(trig)
                       End If
              Reset Watchdog





            If Dan = 0 Then
                       If Instr(text , "S") > 0 Then
                          Trig = Mid(text , 20 , 3)
                          Ns = Val(trig)
                       End If

                       If Instr(text , "E") > 0 Then
                          Trig = Mid(text , 24 , 3)
                          Nf = Val(trig)
                       End If

               If Led > 0 And Led < 99 Then
                  Writeeeprom Led , 6
                  Waitms 1

                  Adss = Led * 4
                  Adss = Adss - 2
                   Adss= 790-Adss
                  Writeeeprom Ns , Adss
                  Waitms 1

                    Adss = Adss +2
                  Writeeeprom Nf , Adss
                  Waitms 1

                  Mmr = 199-led
                  Mmg = 299- led
                  Mmb = 399-led
                  Writeeeprom Rr , Mmr
                  Waitms 1
                  Writeeeprom Gg , Mmg
                  Waitms 1
                  Writeeeprom Bb , Mmb
                  Waitms 1
                   Reset Watchdog
                  R = Rr : G = Gg : B = Bb

                  For I = Ns To Nf
                     Reset Watchdog
                     Rb_setcolor I , Color(1)
                  Next
                     Rb_send
                     Waitms 1
               Else
               select case led
                  case 0:
                     R = Rr : G = Gg : B = Bb
                     For I = Ns To Nf
                        Reset Watchdog
                        Rb_setcolor I , Color(1)
                     Next
                       Rb_send
                        Waitms 1
                  Case 996:
                      call memclr
                  Case 997:
                     Rb_clearstripe
                     Waitms 100
                  Case 998:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 100
                  Case 999:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 1
                     Writeeeprom Rr , 3
                     Waitms 1
                     Writeeeprom Gg , 4
                     Waitms 1
                     Writeeeprom Bb , 5
                     Waitms 1
                     Led = 999
                     Writeeeprom Led , 6
                     Waitms 100
               End Select
               End If
               Reset Watchdog
            Else

              if led<1 then led=1
              if led>999 then led=999
                       If Instr(text , "s") > 0 Then
                          Trig = Mid(text , 20 , 3)
                          Tim1 = Val(trig)
                       End If

                       If Instr(text , "e") > 0 Then
                          Trig = Mid(text , 24 , 3)
                          Tim2 = Val(trig)
                       End If
               call chekm
               If Danc > 0 and Danc <100    Then
                  Writeeeprom Rr , 3
                  Waitms 1
                  Writeeeprom Gg , 4
                  Waitms 1
                  Writeeeprom Bb , 5
                  Waitms 1
                  Writeeeprom Led , 6
                  Waitms 1
                  Writeeeprom Tim1 , 10
                  Waitms 1
                  Writeeeprom Tim2 , 12
                  Waitms 1
                  Reset Watchdog
               end if
            End If


         End If
 End If
        'Print "a=" ; Ch ; "d=" ; Danc ; "r=" ; Rr ; "g=" ; Gg ; "b=" ; _
         'Bb ; "s=" ; Ns ; "e=" ; Nf ; "m=" ; Led
      Text = ""
      Trig = ""
      Ch = ""
      Reset Watchdog
      ina=0
goto main

Modh:

   If Led = 0 Then Led = 1
   If Danc = 99 Then
        Reset Watchdog
         Dans = Rnd(38)
   Else
      Dans = Danc - 1

   End If

  If Rr <251  Then
      Rx = Rr
   Else
      rx=251
      Select Case Rr
         Case 251
            Rx = Rnd(15)
         Case 252
            Rx = Rnd(30)
         Case 253
            Rx = Rnd(60)
         Case 254
            Rx = Rnd(120)
         Case 255
            Rx = Rnd(250)
      End Select
      R = Rx
   End If

   If Gg <251  Then
      Gx = Gg
   Else
      gx=251
      Select Case Gg
         Case 251
            gx = Rnd(15)
         Case 252
            gx = Rnd(30)
         Case 253
            gx = Rnd(60)
         Case 254
            gx = Rnd(120)
         Case 255
            gx = Rnd(250)
      End Select
      G = Gx
   End If

   If Bb <251  Then
      Bx = Bb
   Else
      bx=251
      Select Case Bb
         Case 251
            bx = Rnd(15)
         Case 252
            bx = Rnd(30)
         Case 253
            bx = Rnd(60)
         Case 254
            bx = Rnd(120)
         Case 255
            bx = Rnd(250)
      End Select
      B = Bx
   End If

  Select Case Dans

  Case 0:call snak_run_slow
  Case 1:call snak_return_slow
  case 2:
  call snak_run_slow
  call snak_return_slow
  Case 3:call snak_run_fast
  Case 4:call snak_return_fast
  Case 5:
  call snak_run_fast
  call snak_return_fast

  Case 6:call snak_run_slow_random
  Case 7:call snak_return_slow_random
  case 8:
  call snak_run_slow_random
  call snak_return_slow_random
  Case 9:call snak_run_fast_random
  Case 10:call snak_return_fast_random
  Case 11:
  call snak_run_fast_random
  call snak_return_fast_random
  case 12 :call snak_runreturn_slow_random
  case 13 :call half_snak_out_mid_slow
  case 14 :call half_snak_mid_out_slow
  case 15 :
  call half_snak_out_mid_slow
  call half_snak_mid_out_slow
  case 16:call half_half_right_slow
  case 17:call half_half_left_slow
  case 18:call star_run_slow
  case 19:call star_return_slow
  case 20:call star_runreturn_slow
  case 21:call star_run_fast
  case 22:call star_return_fast
  case 23:
  call star_run_fast
  call star_return_fast
  case 24:call snak_growup_slow
  case 25:call star_playful
  case 26:call snak_star_playful
  CASE 27:call star_fillers
  Case 28:call movable_light
  Case 29:call snak_runreturn_colored
  Case 30:call star_diamonds_blink_slow
  Case 31:call star_diamonds_blink_fast
  Case 32:call star_diamonds_blink_faster
  Case 33:call disco
  Case 34:call fillstripe_Color
  Case 35:call breathing
  Case 36:call percolate
  Case 37:call percolate_snak
  case 38:call half_percolate_solid
  End Select
Goto Main



sub chekm
    If Tim1 > 999 or tim1<1  Then Tim1 =1
    If Tim2 > 999 or tim2<1  Then Tim2 =1
end sub

Sub Time1
   Call Chekm
   For Tt1 = 0 To Tim1
      Reset Watchdog
      Waitms 1
   next
End Sub

Sub Time2
   Call Chekm
   For Tt2 = 0 To Tim2
      Reset Watchdog
      Waitms 1
   next
End Sub

sub memclr
                     r=0
                     print "   "
                      print " Rangmang209 Wait "
                     For ii = 0 To 800
                        Writeeeprom R , ii
                        Reset Watchdog
                     Next
                      print " Clear :) "
                     Rb_clearstripe
end sub



''''''''''''''efects
   sub  snak_run_slow

       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led

          Rb_setcolor Nd , Color(1)
          call time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led

           Rb_setcolor Nd , Color(1)
           call time2
           Rb_send
        Next
     end sub

    sub snak_return_slow

       R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -1

          Rb_setcolor Nd , Color(1)
          call time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = Led To 0 Step -1

           Rb_setcolor Nd , Color(1)
           call time2
           Rb_send
        Next
     end sub

     sub snak_run_fast                                '
       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led step 5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
          call time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led step 5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
           call time2
           Rb_send
        Next
     end sub

     sub snak_return_fast
       R = Rx : G = Gx : B = Bx
       For Nd = led To 0 step -5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
          call time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = led To 0 step -5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
           call time2
           Rb_send
        Next
      end sub

     sub  snak_run_slow_random
            For Nd = 0 To Led

             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             call time2
             Rb_send
           Next
           Rb_clearstripe
      end sub
      sub  snak_return_slow_random
            For Nd = Led To 0 Step -1
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
           Rb_clearstripe
    end sub

    sub  snak_run_fast_random
            For Nd = 0 To Led step 5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               xfd=nd+1
               yfd=nd+2
               vfd=nd+3
               bfd=nd+4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
               Rb_send
               call time1
            Next
            R = 0 : G = 0 : B = 0
            For Nd = 0 To Led step 5
               xfd=nd+1
               yfd=nd+2
               vfd=nd+3
               bfd=nd+4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
               Rb_send
               call time2
            Next
            Rb_clearstripe
      end sub
      sub  snak_return_fast_random
            For Nd = Led To 4 Step -5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               xfd=nd-1
               yfd=nd-2
               vfd=nd-3
               bfd=nd-4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
             call time1
             Rb_send
            Next
           R = 0 : G = 0 : B =0
            For Nd = Led To 4 Step -5
               xfd=nd-1
               yfd=nd-2
               vfd=nd-3
               bfd=nd-4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
             call time2
             Rb_send
            Next
            Rb_clearstripe
      end sub

    sub snak_runreturn_slow_random
                   For Nd = Led To 0 Step -1

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             call time2
             Rb_send
           Next

            For Nd = 0 To Led

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
    end sub


     sub half_snak_out_mid_slow
        I = Led
        Jj = Led / 2
       For Nd = 0 To Jj

         R = Rx : G = Gx : B = Bx
         Rb_setcolor Nd , Color(1)
         Waitus 10
         Rb_send
         Decr I
         Rb_setcolor I , Color(1)
         call time1
         Rb_send
       Next
          call time2
         Rb_clearcolors
       end sub
     sub half_snak_mid_out_slow
        Jj = Led / 2
        I = Jj
       For Nd = Jj To 0 Step -1

         R = Rx : G = Gx : B = Bx
         Rb_setcolor Nd , Color(1)
         Waitus 10
         Rb_send
         Incr I
         Rb_setcolor I , Color(1)
         call time1
         Rb_send
       Next
          call time2
         Rb_clearcolors
     end sub

      sub half_half_right_slow
               I = Led
        Jj = Led / 2
       For Nd = Jj To 0 Step -1

         R = Rx : G = Gx : B = Bx
         Rb_setcolor Nd , Color(1)
         Waitus 10
         Rb_send
         Decr I
         Rb_setcolor I , Color(1)
         call time1
         Rb_send
       Next
          call time2
         Rb_clearcolors
       end sub

    sub half_half_left_slow

        Jj = Led / 2
         I = Jj
       For Nd = 0 To Jj

         R = Rx : G = Gx : B = Bx
         Rb_setcolor Nd , Color(1)
         Waitus 10
         Rb_send
         Incr I
         Rb_setcolor I , Color(1)
         call time1
         Rb_send
       Next
          call time2
         Rb_clearcolors
       end sub

   sub star_run_slow
         R = Rx : G = Gx : B = Bx
         If Chc = 0 Then
          Ado = Led
          Chc = 1
          End If
         If Ado = 1 Then Chc = 0

         For Nd = 0 To Ado
         Rb_setcolor Nd , Color(1)
         Rb_send
         Call Time1
         Rb_clearcolors
       Next
       R = 222 : G = 222 : B = 222
         Rb_setcolor Ado , Color(1)
          Rb_send
          Call Time2
       If Chc = 1 Then Decr Ado
   end sub

   sub star_return_slow
         R = Rx : G = Gx : B = Bx
         If Chc = 0 Then
          Ado = Led
          Chc = 1
          End If
         If Ado = 1 Then Chc = 0

         For Nd = 0 To Ado
         Rb_setcolor Nd , Color(1)
         Rb_send
         Call Time1
         Rb_clearcolors
       Next
       R = 222 : G = 222 : B = 222
         Rb_setcolor Ado , Color(1)
          Rb_send
          Call Time2
       If Chc = 1 Then Decr Ado
   end sub

   sub star_runreturn_slow
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led

          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next                                                 'call time1
       For Nd = Led To 0 Step -1

         Rb_setcolor Nd , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   end sub
   sub star_run_fast
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led step 5
               xfd=nd+1
               yfd=nd+2
               vfd=nd+3
               bfd=nd+4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next
     end sub
     sub star_return_fast                                                'call time1
       For Nd = Led To 0 Step -5
               xfd=nd-1
               yfd=nd-2
               vfd=nd-3
               bfd=nd-4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
         Rb_setcolor Nd , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   end sub
sub snak_growup_slow
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send

          IF T<LED THEN   T=T+5
          IF T=> LED THEN T=1

           For N = 1 To Led -T
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -3 Step -1
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -T

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
end sub

sub star_playful
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send
           yfd=rnd(5)
          IF T<LED THEN   T=T+yfd
          IF T=> LED THEN T=1

           For N = 1 To Led -T
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next

           xfd=rnd(5)
           For Nd = Led -1 To Led -xfd Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next
              vfd=rnd(t)
           For N = 1 To Led -vfd

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
end sub

sub snak_star_playful
                IF LED<22 THEN LED=22
           DIM PP AS BYTE
           PP=RND(10):IF PP=0 THEN PP=1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To PP
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next

           PP=RND(10):IF PP=0 THEN PP=1
          IF T<LED THEN   T=T+1
          IF T=> LED THEN T=1
              T=RND(T)
              T=T+PP
              IF T=0 THEN T=1
           For N = 1 To Led -T STEP PP
              IF N>0 THEN
             Rb_shiftright 0 , Led
             Rb_send
             END IF
             Call Time1

           Next


           For Nd = Led -1 To Led -T Step -3
           IF ND>0 THEN
             Rb_setcolor Nd , Color(1)
             Rb_send
           END IF
            Reset Watchdog
             Next

           PP=RND(10):IF PP=0 THEN PP=3
           For N = 1 To Led -T  STEP PP
              IF N>0 THEN
             Rb_shiftleft 0 , Led
             Rb_send
             END IF
             call time2
           Next

       ''''''''''''''''''''''''''''''''''''''''
           PP=RND(10):IF PP=0 THEN PP=1



           PP=RND(10):IF PP=0 THEN PP=1
          IF T<LED THEN   T=T+1
          IF T=> LED THEN T=1
              T=RND(T)
              T=T+PP
              IF T=0 THEN T=1
              Dim Jd , Md As Word
               MD=RND (LED):IF MD<T THEN MD=T+1
           For N = 1 To MD -T STEP PP
           JD=LED-PP
              IF N>0 THEN
             Rb_setcolor N  , Color(1)
             Rb_send
             END IF
             IF JD>0 THEN
             Rb_setcolor JD  , Color(1)
             Rb_send
             END IF
             Call Time1

           Next


           For Nd =Led -T  To  Led -1 Step -3
           IF ND>0 THEN
             Rb_setcolor Nd , Color(1)
             Rb_send
           END IF
             Reset Watchdog
             Next

           PP=RND(10):IF PP=0 THEN PP=3
           For N = Led -T To 1  STEP PP
              IF N>0 THEN
             Rb_shiftRIGHT 0 , Led
             Rb_send
             END IF
             call time2
           Next

            For Nd = 1 To PP
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next
end sub
 sub star_fillers
             If Ado < Led Then Ado = Ado + 1
            If Ado = Led Then Ado = 1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To Ado STEP 4
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next



           For N = 1 To Led -ado STEP -4

             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -ado Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -ado

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
 end sub

 sub movable_light
         if rx>200 then rx=200
        if gx>200 then gx=200
        if bx>200 then bx=200
         For Nd = 2 To Led

             R = 255 : G = 255 : B = 255
             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
             Ndn = Nd - 1
             Rb_setcolor Ndn , Color(1)
             call time2
             Rb_send
             R = Rx : G = Gx : B = Bx
             Ndn = Nd - 2
             Rb_setcolor Ndn , Color(1)
             call time1
             Rb_send
         Next                                                        'call time1
         For Nd = Led -2 To 0 Step -1


           R = 255 : G = 255 : B = 255
             Rb_setcolor Nd , Color(1)
             call time2
             Rb_send
             Ndn = Nd + 1
             Rb_setcolor Ndn , Color(1)
             call time1
             Rb_send
             R = Rx : G = Gx : B = Bx
             Ndn = Nd + 2
             Rb_setcolor Ndn , Color(1)
            call time2
             Rb_send
         Next
 end sub

 sub snak_runreturn_colored
                R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = 0 To Led

             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
         Next
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = Led To 0 Step -1

             Rb_setcolor Nd , Color(1)
             call time2
             Rb_send
         Next
 end sub
 sub star_diamonds_blink_slow
                         R = RND(Rx) : G = RND(Gx) : B = RND(Bx)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   call time2
                   Rb_send
 end sub
  sub star_diamonds_blink_fast
               R = Rx : G = Gx : B = Bx
                   call time1
                   call time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors
 end sub

 sub star_diamonds_blink_faster
                    R = Rx : G = Gx : B = Bx
                   call time1
                   call time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors

 end sub

 sub disco
                   R = Rx : G = Gx : B = Bx
               FOR I=0 TO LED
                   call time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
               NEXT
                  Rb_send
                  R = 0 : G = 0 : B = 0
               FOR I=0 TO LED
                   call time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)

               NEXT
                  Rb_send
 end sub

 sub fillstripe_Color
                  R = RND(Rx) : G = RND(Gx) : B = RND(Bx)
                    Rb_fillstripe Color
                    For I = 0 To 200
                      Call Time1
                      Call Time2
                      Next
 end sub

 sub breathing
                A1 = Rx : A2 = Gx : A3 = Bx
                For Ll = 0 To 255
                  If A1 = 1 Or A2 = 1 Or A3 = 1 Then Exit For
                  If A1 > 1 Then Decr A1
                  If A2 > 1 Then Decr A2
                   If A3 > 1 Then Decr A3
                  R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time1
                Next

              For Ll = 0 To 255
               If A1 = Rx Or A2 = Gx Or A3 = Bx Then Exit For
               If A1 < Rx Then Incr A1
                If A2 < Gx Then Incr A2
                If A3 < Bx Then Incr A3
                R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time2
              Next
 end sub

 sub percolate
                toggle nnb
      if nnb=1 then
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led/2
           R = Rx : G = Gx : B = Bx
          Rb_setcolor Nd , Color(1)
          Rb_send
          call time1

          nnd=led-nd
          Rb_setcolor Nnd , Color(1)
          Rb_send
          call time1

          if nd >0 then
            pnd=nd-1
            R = 0 : G = 0 : B = 0
            Rb_setcolor pnd , Color(1)
            Rb_send
          end if
           call time2

              nnd=nnd+1
              R = 0 : G = 0 : B = 0
              Rb_setcolor Nnd , Color(1)
              Rb_send

           call time2
       Next
      end if

          R = 0 : G = 0 : B = 0
          nd=led/2
          Rb_setcolor Nd , Color(1)
          Rb_send
          call time1
      if nnb=0 then
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led/2
           R = Rx : G = Gx : B = Bx
           nnd=led/2
           nnd=nnd-nd
          Rb_setcolor Nnd , Color(1)
          Rb_send
          call time1

          pnd=led/2
          pnd=pnd+nd
          Rb_setcolor pnd , Color(1)
          Rb_send
          call time1


           nnd=nnd+1
            R = 0 : G = 0 : B = 0
            Rb_setcolor nnd , Color(1)
            Rb_send

           call time2

              pnd=pnd-1
              R = 0 : G = 0 : B = 0
              Rb_setcolor pnd , Color(1)
              Rb_send

           call time2
       Next
      end if
 end sub

 sub percolate_snak
            toggle nnb
      if nnb=1 then
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led/2
           R = Rx : G = Gx : B = Bx
          Rb_setcolor Nd , Color(1)
          Rb_send
          call time1

          nnd=led-nd
          Rb_setcolor Nnd , Color(1)
          Rb_send
          call time1

          if nd >0 then
            pnd=nd-1
            R = 0 : G = 0 : B = 0
            Rb_setcolor pnd , Color(1)
            Rb_send
          end if
           call time2

              nnd=nnd+1
              R = 0 : G = 0 : B = 0
              Rb_setcolor Nnd , Color(1)
              Rb_send

           call time2
       Next
      end if

          R = 0 : G = 0 : B = 0
          nd=led/2
          'nd=nd+1
          Rb_setcolor Nd , Color(1)
          Rb_send
          call time1
      if nnb=0 then
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led/2
           R = Rx : G = Gx : B = Bx
           nnd=led/2
           nnd=nnd-nd
          Rb_setcolor Nnd , Color(1)
          Rb_send
          call time1

          pnd=led/2
          pnd=pnd+nd
          Rb_setcolor pnd , Color(1)
          Rb_send
          call time1



       Next
      end if
 end sub

 sub half_percolate_solid
            toggle nnb
       if nnb=1 then
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led/2
           R = Rx : G = Gx : B = Bx
          Rb_setcolor Nd , Color(1)
          Rb_send
          call time1

          nnd=led-nd
          Rb_setcolor Nnd , Color(1)
          Rb_send
          call time1

          if nd >0 then
            pnd=nd+1
            R = 0 : G = 0 : B = 0
            Rb_setcolor pnd , Color(1)
            Rb_send
          end if
           call time2

              nnd=nnd-1
              R = 0 : G = 0 : B = 0
              Rb_setcolor Nnd , Color(1)
              Rb_send

           call time2
       Next
      end if

          R = 0 : G = 0 : B = 0
          nd=led/2
          Rb_setcolor Nd , Color(1)
          Rb_send
          call time1
      if nnb=0 then
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led/2
           R = Rx : G = Gx : B = Bx
           nnd=led/2
           Nnd = Nnd - nd
          Rb_setcolor Nnd , Color(1)
          Rb_send
          call time1

          pnd=led/2
          pnd=pnd+nd
          Rb_setcolor pnd , Color(1)
          Rb_send
          call time1

       Next
      end if
 End Sub