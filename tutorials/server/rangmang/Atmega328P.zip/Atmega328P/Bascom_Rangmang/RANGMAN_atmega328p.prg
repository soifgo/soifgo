FF
BE
CF
FE
N
N
N
