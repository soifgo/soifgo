 ' Saeid Moghadam
' SSMQQMSS@gmail.com
' SoifGo

' Rangmang ATmega328 � 480 pixels
' 30 inputs
' ADRGBSEM
' A00D00R000G000B000S000E000M000
' A01 TO A98   FOR ADDRESS MODULE   A99 FOR ALL
' IF D00 THEN SOLID COLOR
' R000 TO R255   RED COLOR
' G000 TO G255   GREEN COLOR
' B000 TO B255   BLUE COLOR
' S000 TO S480   RGB STRIP START POSITION FOR COLORED PIXEL
' E000 TO E480   RGB STRIP END POSITION FOR COLORED PIXEL
' M000 TO M098   M000 WITHOUT MEMORY SAVE   M001 SAVE SLOT 1 MEMORY

' IF D01 TO D55   DANCE
' D99   FOR RANDOM SELECT D01 TO D55 DANCE
' R000 TO R250   RED COLOR   R251 TO R255 FOR RANDOM RED COLOR
' G000 TO G250   GREEN COLOR   G251 TO G255 FOR RANDOM GREEN COLOR
' B000 TO B250   BLUE COLOR   B251 TO B255 FOR RANDOM BLUE COLOR
' S000 TO S999   RGB STRIP FIRST DELAY EFFECT (ms)
' E000 TO E999   RGB STRIP SECOND DELAY EFFECT (ms)
' M001 TO M480   SET HOW MANY PIXELS DANCING


$regfile = "m328pdef.dat"
$crystal = 1105920
$prog &HFF , &HBE , &HCF , &HFE                             '328
$hwstack=40
$swstack=16
$framesize = 32


Dim Ina As Bit                                              'external crystal 11059200
Config Watchdog = 1024
 Enable Interrupts
 $baud = 960
 Reset Watchdog
Ff:
'----[MAIN]---------------------------------------------------------------------
   Dim Danc , Dan , Dans As Byte
   Dim N , Nd , Ndn , Ns , Nf , Jj , Led , S,ii,I,t As Word
   Dim Ch , Ch0 , A1 , A2 , A3 As Byte
   Dim Text As String * 32
   Dim Trig As String * 4
   Dim Trig2 As String * 3
   Dim Rq(99) , Gq(99) , Bq(99) As Byte
   Dim  Rgb , Mmr , Mmg , Mmb As Byte
   Dim Tim1 , Tim2 , Tt1 , Tt2 , Ado , Ll, Adss,ADSS2 , Adsm,ADSm2  As Word
   Dim Rr , Gg , Bb As Byte
   Dim Rx , Gx , Bx As Byte
   Dim Chc , Nnb , Mx,rainbo As Bit
   Dim Nnd , Pnd , Jk , Kk , Lk As Word
   Dim Dvado As Word
  ''''''''''''''''''''''''''''''''''
  dim xfd,yfd,vfd,bfd as word


   dim memoclr as byte
   Declare Sub memclr                                        ' select first chann
   Declare Sub Chekm
   Declare Sub time1
   Declare Sub time2
   Readeeprom Ch0 , 1
   Readeeprom Dan , 2
   Readeeprom Rr , 3
   Readeeprom Gg , 4
   Readeeprom Bb , 5
   Readeeprom Led , 6
   Readeeprom memoclr , 9
   Readeeprom Tim1 , 10
   Readeeprom Tim2 , 12
   call chekm
   If Ch0 > 98 Or Ch0 <1 Then Ch0 = 1
   If Dan > 99 Then Dan = 0
   If Led >990 Then Led = 990

    if memoclr=0 or memoclr>1 then
      call memclr
      memoclr=1
      writeeeprom memoclr , 9
    end if


   Danc = Dan

   Config Rainbow = 1 , Rb0_len = 489 , Rb0_port = Portd , Rb0_pin = 5
   Dim Color(3) As Byte
   R Alias Color(_base) : G Alias Color(_base + 1) : B Alias Color(_base + 2)
   Rb_selectchannel 0
   Rb_clearcolors
   Rb_clearstripe

   Reset Watchdog

   For I = 1 To 98
      Mmr = I + 100
      Mmg = I + 200
      Mmb = I + 300

      Readeeprom Rgb , Mmr
      Rq(i) = Rgb
      Readeeprom Rgb , Mmg
      Gq(i) = Rgb
      Readeeprom Rgb , Mmb
      Bq(i) = Rgb
      Reset Watchdog
     If Dan = 0 Then
      If Led > 0 And Led < 99 Then
            Reset Watchdog
            Adss = i*4
            Adss = Adss +396
            R = Rq(i) : G = Gq(i) : B = Bq(i)
           adss2=adss+2
            Readeeprom Adsm , Adss
             Readeeprom Adsm2 , Adss2
            For S = adsm To adsm2
               Reset Watchdog
               Rb_setcolor S , Color(1)
            Next

               Rb_send
      Else
         If Led = 999 Then
            Reset Watchdog
            R = rr : G = gg : B = bb
            Rb_fillstripe Color
         End If
      End If
     End If
   Next

dim error as byte

 Config Serialin = Buffered , Size = 34 , Bytematch = 13
   Reset Watchdog
   Clear Serialin
   '''''''''''''''''''''''''''''dance subs'''''''''
  Declare Sub snak_run_slow
  Declare Sub snak_return_slow
  Declare Sub snak_run_fast
  Declare Sub snak_return_fast
  Declare Sub snak_run_slow_random
  Declare Sub snak_return_slow_random
  Declare Sub snak_run_fast_random
  Declare Sub snak_return_fast_random
  Declare Sub snak_runreturn_slow_random
  Declare Sub Half_snak_out_mid_slow
  Declare Sub half_half_right_slow
  Declare Sub half_half_left_slow
  Declare Sub star_runreturn_slow
  Declare Sub Star_run_slow
  Declare Sub star_run_fast
  Declare Sub star_return_fast
  Declare Sub snak_growup_slow
  Declare Sub star_playful
  Declare Sub snak_star_playful
  Declare Sub star_fillers
  declare sub movable_light
  declare sub snak_runreturn_colored
  declare sub star_diamonds_blink_slow
  declare sub star_diamonds_blink_fast
  declare sub star_diamonds_blink_faster
  declare sub disco
  declare sub fillstripe_Color
  declare sub breathing
  Declare Sub Percolate_run
  Declare Sub Percolate_return
  Declare Sub Snak_1_2_run
  Declare Sub Snak_1_2_return
  Declare Sub Snak_1_2_run_rev
  Declare Sub Snak_1_2_return_rev
  Declare Sub Snak_relax_run
  Declare Sub Snak_relax_return
  Declare Sub Snak_rainbow
 Declare Sub Snak_rainbow_lp
  Declare Sub Snak_rainbow_bl
   Echo On
   Dim Pos As Byte
   Echo Off
Do
  Main:
   Reset Watchdog
   If Ina = 1 Then Goto Red
  If Danc > 0 and ina=0 Then Goto Modh
Loop

Serial0charmatch:
      Input Text
      Clear Serialin

   Ina = 1
Return


red:


  Text = Trim(text)
  Text = Ltrim(text)
   Pos = Instr(text , "A")



  Reset Watchdog

   Hh:
   If Instr(text , "CH") > 0 Then
        Trig = Mid(text , 3 , 2)

         If Ch0 = Val(trig) Then
           Trig2 = Mid(text , 6 , 2)
           Ch = Val(trig2)
              If Ch > 0 And Ch < 99 Then
                Ch0 = Ch
                Writeeeprom Ch0 , 1
                Waitms 1
               Print "New Address=" ; Ch0

              End If

         End If


   End If


 If Pos > 0 Then

     Text = Mid(text , Pos)




         If Instr(text , "A") > 0 Then
            Trig = Mid(text , 2 , 2)
           Ch = Val(trig)

         End If


         If Ch = Ch0 Or Ch = 99 Then

           If Instr(text , "D") > 0 Then
              Trig = Mid(text , 5 , 2)

              Danc = Val(trig)
              Dan = Danc
           End If

             If Danc > 99 Then Dan = 0
              Writeeeprom Dan , 2
              Waitms 1
                       If Instr(text , "R") > 0 Then
                          Trig = Mid(text , 8 , 3)
                          R = Val(trig)
                          Rr = R
                       End If
                       If Instr(text , "G") > 0 Then
                          Trig = Mid(text , 12 , 3)
                          G = Val(trig)
                          Gg = G
                       End If

                       If Instr(text , "B") > 0 Then
                          Trig = Mid(text , 16 , 3)
                          B = Val(trig)
                          Bb = B
                       End If
                       If Instr(text , "M") > 0 Then
                          Trig = Mid(text , 28 , 3)
                          Led = Val(trig)
                       End If
              Reset Watchdog





            If Dan = 0 Then
                       If Instr(text , "S") > 0 Then
                          Trig = Mid(text , 20 , 3)
                          Ns = Val(trig)
                       End If

                       If Instr(text , "E") > 0 Then
                          Trig = Mid(text , 24 , 3)
                          Nf = Val(trig)
                       End If

               If Led > 0 And Led < 99 Then
                  Writeeeprom Led , 6
                  Waitms 1

                  Adss = Led * 4
                  Adss = Adss - 2
                   Adss= 790-Adss
                  Writeeeprom Ns , Adss
                  Waitms 1

                    Adss = Adss +2
                  Writeeeprom Nf , Adss
                  Waitms 1

                  Mmr = 199-led
                  Mmg = 299- led
                  Mmb = 399-led
                  Writeeeprom Rr , Mmr
                  Waitms 1
                  Writeeeprom Gg , Mmg
                  Waitms 1
                  Writeeeprom Bb , Mmb
                  Waitms 1
                   Reset Watchdog
                  R = Rr : G = Gg : B = Bb

                  For I = Ns To Nf
                     Reset Watchdog
                     Rb_setcolor I , Color(1)
                  Next
                     Rb_send
                     Waitms 1
               Else
               select case led
                  case 0:
                     R = Rr : G = Gg : B = Bb
                     For I = Ns To Nf
                        Reset Watchdog
                        Rb_setcolor I , Color(1)
                     Next
                       Rb_send
                        Waitms 1
                  Case 996:
                      call memclr
                  Case 997:
                     Rb_clearstripe
                     Waitms 100
                  Case 998:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 100
                  Case 999:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 1
                     Writeeeprom Rr , 3
                     Waitms 1
                     Writeeeprom Gg , 4
                     Waitms 1
                     Writeeeprom Bb , 5
                     Waitms 1
                     Led = 999
                     Writeeeprom Led , 6
                     Waitms 100
               End Select
               End If
               Reset Watchdog
            Else

              if led<1 then led=1
              if led>999 then led=999
                       If Instr(text , "S") > 0 Then
                          Trig = Mid(text , 20 , 3)
                          Tim1 = Val(trig)
                       End If

                       If Instr(text , "E") > 0 Then
                          Trig = Mid(text , 24 , 3)
                          Tim2 = Val(trig)
                       End If
               call chekm
               If Danc > 0 and Danc <100    Then
                  Writeeeprom Rr , 3
                  Waitms 1
                  Writeeeprom Gg , 4
                  Waitms 1
                  Writeeeprom Bb , 5
                  Waitms 1
                  Writeeeprom Led , 6
                  Waitms 1
                  Writeeeprom Tim1 , 10
                  Waitms 1
                  Writeeeprom Tim2 , 12
                  Waitms 1
                  Reset Watchdog
               end if
            End If


         End If
 End If
        'Print "a=" ; Ch ; "d=" ; Danc ; "r=" ; Rr ; "g=" ; Gg ; "b=" ; _
         'Bb ; "s=" ; Ns ; "e=" ; Nf ; "m=" ; Led
      Text = ""
      Trig = ""
      Ch = ""
      Reset Watchdog
      ina=0
goto main

Modh:

   If Led = 0 Then Led = 1
   If Danc = 99 Then
        Reset Watchdog
         Dans = Rnd(55)
   Else
      Dans = Danc - 1

   End If

  If Rr <251  Then
      Rx = Rr
   Else
      rx=251
      Select Case Rr
         Case 251
            Rx = Rnd(15)
         Case 252
            Rx = Rnd(30)
         Case 253
            Rx = Rnd(60)
         Case 254
            Rx = Rnd(120)
         Case 255
            Rx = Rnd(250)
      End Select
      R = Rx
   End If

   If Gg <251  Then
      Gx = Gg
   Else
      gx=251
      Select Case Gg
         Case 251
            gx = Rnd(15)
         Case 252
            gx = Rnd(30)
         Case 253
            gx = Rnd(60)
         Case 254
            gx = Rnd(120)
         Case 255
            gx = Rnd(250)
      End Select
      G = Gx
   End If

   If Bb <251  Then
      Bx = Bb
   Else
      bx=251
      Select Case Bb
         Case 251
            bx = Rnd(15)
         Case 252
            bx = Rnd(30)
         Case 253
            bx = Rnd(60)
         Case 254
            bx = Rnd(120)
         Case 255
            bx = Rnd(250)
      End Select
      B = Bx
   End If

  Select Case Dans

  Case 0:call snak_run_slow
  Case 1:call snak_return_slow
  case 2:
  call snak_run_slow
  call snak_return_slow
  Case 3:call snak_run_fast
  Case 4:call snak_return_fast
  Case 5:
  call snak_run_fast
  call snak_return_fast

  Case 6:call snak_run_slow_random
  Case 7:call snak_return_slow_random
  case 8:
  call snak_run_slow_random
  call snak_return_slow_random
  Case 9:call snak_run_fast_random
  Case 10:call snak_return_fast_random
  Case 11:
  call snak_run_fast_random
  call snak_return_fast_random
  case 12 :call snak_runreturn_slow_random
  Case 13 :
  Nnb = 0
  Call Half_snak_out_mid_slow
  Case 14 :
  Nnb = 1
  Call Half_snak_out_mid_slow
  Case 15 :
   Call Half_snak_out_mid_slow
   Toggle Nnb
      Goto Modh
  Case 16 : Call Half_half_right_slow
  case 17:call half_half_left_slow
  Case 18 :
  Mx = 0
   Call Star_run_slow
   Case 19 :
   Mx = 1
    Call Star_run_slow
  Case 20 : Call Star_runreturn_slow
  Case 21 : Call Star_run_fast
  Case 22 : Call Star_return_fast
  Case 23:
  call star_run_fast
  call star_return_fast
  Case 24 : Call Snak_growup_slow
  Case 25 : Call Star_playful
  Case 26 : Call Snak_star_playful
  Case 27 : Call Star_fillers
  Case 28 : Call Movable_light
  Case 29 : Call Snak_runreturn_colored
  Case 30 : Call Star_diamonds_blink_slow
  Case 31 : Call Star_diamonds_blink_fast
  Case 32 : Call Star_diamonds_blink_faster
  Case 33 : Call Disco
  Case 34 : Call Fillstripe_color
  Case 35 : Call Breathing
  Case 36 : Call Percolate_run
  Case 37 : Call Percolate_return
  Case 38 :
   Call Percolate_run
   Call Percolate_return
  Case 39 : Call Snak_1_2_run
  Case 40 : Call Snak_1_2_return
   Case 41 :
    Call Snak_1_2_run
    Call Snak_1_2_return
  Case 42 : Call Snak_1_2_run_rev
  Case 43 : Call Snak_1_2_return_rev
   Case 44 :
    Call Snak_1_2_run_rev
    Call Snak_1_2_return_rev
  Case 45 : Call Snak_relax_run
  Case 46 : Call Snak_relax_return
   Case 47 :
    Call Snak_relax_run
    Call Snak_relax_return
    Case 48 :
    Rainbo = 0
     Call Snak_rainbow
  Case 49 :
  Rainbo = 1
   Call Snak_rainbow
   Case 50 :
   Rainbo = 0
    Call Snak_rainbow
      Rainbo = 1
    Call Snak_rainbow

        Case 51 :
    Rainbo = 0
     Call Snak_rainbow_lp
  Case 52 :
  Rainbo = 1
   Call Snak_rainbow_lp
   Case 53 :
   Rainbo = 0
    Call Snak_rainbow_lp
      Rainbo = 1
    Call Snak_rainbow_lp
     Case 54 : Call Snak_rainbow_bl
  End Select
Goto Main



sub chekm
    If Tim1 > 999 or tim1<1  Then Tim1 =1
    If Tim2 > 999 or tim2<1  Then Tim2 =1
end sub

Sub Time1
   Call Chekm
   For Tt1 = 0 To Tim1
      Reset Watchdog
      Waitms 1
      If Ina = 1 Then Exit For
   next
     If Ina = 1 Then Goto Red
End Sub

Sub Time2
   Call Chekm
   For Tt2 = 0 To Tim2
      Reset Watchdog
      Waitms 1
      If Ina = 1 Then Exit For
   Next
   If Ina = 1 Then goto red
End Sub

sub memclr
                     r=0
                     print "   "
                      Print " Rangmang Wait "
                     For ii = 0 To 800
                        Writeeeprom R , ii
                        Reset Watchdog
                     Next
                      print " Clear :) "
                     Rb_clearstripe
end sub



''''''''''''''efects
   sub  snak_run_slow

       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led

          Rb_setcolor Nd , Color(1)
          call time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led

           Rb_setcolor Nd , Color(1)
           call time2
           Rb_send
        Next
     end sub

    sub snak_return_slow

       R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -1

          Rb_setcolor Nd , Color(1)
          call time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = Led To 0 Step -1

           Rb_setcolor Nd , Color(1)
           call time2
           Rb_send
        Next
     end sub

     sub snak_run_fast                                '
       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led step 5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
          call time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led step 5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
           call time2
           Rb_send
        Next
     end sub

     sub snak_return_fast
       R = Rx : G = Gx : B = Bx
       For Nd = led To 0 step -5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
          call time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = led To 0 step -5
          xfd=nd+1
          yfd=nd+2
          vfd=nd+3
          bfd=nd+4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor xfd , Color(1)
          Rb_setcolor yfd , Color(1)
          Rb_setcolor vfd , Color(1)
          Rb_setcolor bfd , Color(1)
           call time2
           Rb_send
        Next
      end sub

     sub  snak_run_slow_random
            For Nd = 0 To Led

             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             call time2
             Rb_send
           Next
           Rb_clearstripe
      end sub
      sub  snak_return_slow_random
            For Nd = Led To 0 Step -1
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
           Rb_clearstripe
    end sub

    sub  snak_run_fast_random
            For Nd = 0 To Led step 5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               xfd=nd+1
               yfd=nd+2
               vfd=nd+3
               bfd=nd+4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
               Rb_send
               call time1
            Next
            R = 0 : G = 0 : B = 0
            For Nd = 0 To Led step 5
               xfd=nd+1
               yfd=nd+2
               vfd=nd+3
               bfd=nd+4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
               Rb_send
               call time2
            Next
            Rb_clearstripe
      end sub
      sub  snak_return_fast_random
            For Nd = Led To 4 Step -5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               xfd=nd-1
               yfd=nd-2
               vfd=nd-3
               bfd=nd-4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
             call time1
             Rb_send
            Next
           R = 0 : G = 0 : B =0
            For Nd = Led To 4 Step -5
               xfd=nd-1
               yfd=nd-2
               vfd=nd-3
               bfd=nd-4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
             call time2
             Rb_send
            Next
            Rb_clearstripe
      end sub

    sub snak_runreturn_slow_random
                   For Nd = Led To 0 Step -1

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             call time2
             Rb_send
           Next

            For Nd = 0 To Led

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
    end sub


     sub half_snak_out_mid_slow
                R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         If Nnb = 0 Then
         For Nd = 0 To Jk
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
         Next

         Else

         For Nd = Jk To 0 Step -1
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
         Next

         End If

       end sub


      sub half_half_right_slow
          Rb_clearcolors
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = 0 To Jk
               Kk = Jk + Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
            Call Time1
             Rb_send
         Next

       end sub

    sub half_half_left_slow
        Rb_clearcolors
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = Jk To 0 Step -1
               Kk = Jk + Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
            Call Time1
             Rb_send
         Next

       end sub

   Sub Star_run_slow

         If Chc = 0 Then
           Ado = Led
           Chc = 1
         End If
         If Ado = 1 Then Chc = 0

         For Nd = 0 To Ado Step 2
              If Mx = 0 Then
                 R = Rx : G = Gx : B = Bx
               Else
                 R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
              End If
              Dvado = Nd + 1
             Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
             Rb_send
             Call Time1
             Rb_clearcolors
         Next
      If Mx = 0 Then
          R = 222 : G = 222 : B = 222
         Else
          R = Rnd(222) : G = Rnd(222) : B = Rnd(222)
      End If




         If Ado > 10 Then

              Dvado = Ado / 10
            For Nd = Ado To Ado + Dvado
                Rb_setcolor Nd , Color(1)
            Next
           Else
           Rb_setcolor Ado , Color(1)
          End If
          Rb_send
          Call Time2
        If Chc = 1 Then
          If Ado > 10 Then
             Ado = Ado - Dvado
          Else
             Decr Ado
          End If
        End If

   end sub


   sub star_runreturn_slow
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
              Dvado = Nd + 1
             Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
               Dvado = Nd + 2
              Rb_setcolor Dvado , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next                                                 'call time1
       For Nd = Led To 0 Step -2
              Dvado = Nd + 1
              Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
              Dvado = Nd + 2
              Rb_setcolor Dvado , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   end sub
   sub star_run_fast
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led step 5
               xfd=nd+1
               yfd=nd+2
               vfd=nd+3
               bfd=nd+4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next
     end sub
     sub star_return_fast                                                'call time1
       For Nd = Led To 5 Step -5
               xfd=nd-1
               Yfd = Nd - 2
               vfd=nd-3
               bfd=nd-4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor xfd , Color(1)
               Rb_setcolor yfd , Color(1)
               Rb_setcolor vfd , Color(1)
               Rb_setcolor bfd , Color(1)
         Rb_setcolor Nd , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   end sub
sub snak_growup_slow
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send

          IF T<LED THEN   T=T+5
          IF T=> LED THEN T=1

           For N = 1 To Led -T
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -3 Step -1
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -T

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
end sub

sub star_playful
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send
           yfd=rnd(5)
          IF T<LED THEN   T=T+yfd
          IF T=> LED THEN T=1

           For N = 1 To Led -T
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next

           xfd=rnd(5)
           For Nd = Led -1 To Led -xfd Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next
              vfd=rnd(t)
           For N = 1 To Led -vfd

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
end sub

sub snak_star_playful
                IF LED<22 THEN LED=22
           DIM PP AS BYTE
           PP=RND(10):IF PP=0 THEN PP=1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To PP
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next

           PP=RND(10):IF PP=0 THEN PP=1
          IF T<LED THEN   T=T+1
          IF T=> LED THEN T=1
              T=RND(T)
              T=T+PP
              IF T=0 THEN T=1
           For N = 1 To Led -T STEP PP
              IF N>0 THEN
             Rb_shiftright 0 , Led
             Rb_send
             END IF
             Call Time1

           Next


           For Nd = Led -1 To Led -T Step -3
           IF ND>0 THEN
             Rb_setcolor Nd , Color(1)
             Rb_send
           END IF
            Reset Watchdog
             Next

           PP=RND(10):IF PP=0 THEN PP=3
           For N = 1 To Led -T  STEP PP
              IF N>0 THEN
             Rb_shiftleft 0 , Led
             Rb_send
             END IF
             call time2
           Next

       ''''''''''''''''''''''''''''''''''''''''
           PP=RND(10):IF PP=0 THEN PP=1



           PP=RND(10):IF PP=0 THEN PP=1
          IF T<LED THEN   T=T+1
          IF T=> LED THEN T=1
              T=RND(T)
              T=T+PP
              IF T=0 THEN T=1
              Dim Jd , Md As Word
               MD=RND (LED):IF MD<T THEN MD=T+1
           For N = 1 To MD -T STEP PP
           JD=LED-PP
              IF N>0 THEN
             Rb_setcolor N  , Color(1)
             Rb_send
             END IF
             IF JD>0 THEN
             Rb_setcolor JD  , Color(1)
             Rb_send
             END IF
             Call Time1

           Next


           For Nd =Led -T  To  Led -1 Step -3
           IF ND>0 THEN
             Rb_setcolor Nd , Color(1)
             Rb_send
           END IF
             Reset Watchdog
             Next

           PP=RND(10):IF PP=0 THEN PP=3
           For N = Led -T To 1  STEP PP
              IF N>0 THEN
             Rb_shiftRIGHT 0 , Led
             Rb_send
             END IF
             call time2
           Next

            For Nd = 1 To PP
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next
end sub
 sub star_fillers
             If Ado < Led Then Ado = Ado + 1
            If Ado = Led Then Ado = 1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To Ado STEP 4
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next



           For N = 1 To Led -ado STEP -4

             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -ado Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -ado

             Rb_shiftleft 0 , Led
             call time2
             Rb_send
           Next
 end sub

 Sub Movable_light
           Xfd = Rnd(rx) : Yfd = Rnd(gx) : Vfd = Rnd(bx)
         For Nd = 0 To Led
             R = 222 : G = 222 : B = 222
             Jk = Nd + 1
             Kk = Nd + 2
             Lk = Nd + 3
             Rb_setcolor Lk , Color(1)
             Rb_setcolor Kk , Color(1)
             Rb_setcolor Jk , Color(1)
              R = Xfd : G = Yfd : B = Vfd
             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
         Next
           Xfd = Rnd(rx) : Yfd = Rnd(gx) : Vfd = Rnd(bx)
         For Nd = Led To 0 Step -1

             R = 222 : G = 222 : B = 222
             Jk = Nd + 1
             Kk = Nd + 2
             Lk = Nd + 3
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Jk , Color(1)
             Rb_setcolor Kk , Color(1)
              R = Xfd : G = Yfd : B = Vfd
             Rb_setcolor Lk , Color(1)
             Call Time2
             Rb_send
         Next
 end sub

 sub snak_runreturn_colored
                R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = 0 To Led

             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
         Next
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = Led To 0 Step -1

             Rb_setcolor Nd , Color(1)
             call time2
             Rb_send
         Next
 end sub
 sub star_diamonds_blink_slow
                         R = RND(Rx) : G = RND(Gx) : B = RND(Bx)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   call time2
                   Rb_send
 end sub
  sub star_diamonds_blink_fast
               R = Rx : G = Gx : B = Bx
                   call time1
                   call time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors
 end sub

 sub star_diamonds_blink_faster
                    R = Rx : G = Gx : B = Bx
                   call time1
                   call time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors

 end sub

 sub disco
                   R = Rx : G = Gx : B = Bx
               FOR I=0 TO LED
                   call time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
               NEXT
                  Rb_send
                  R = 0 : G = 0 : B = 0
               FOR I=0 TO LED
                   call time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)

               NEXT
                  Rb_send
 end sub

 sub fillstripe_Color
                  R = RND(Rx) : G = RND(Gx) : B = RND(Bx)
                    Rb_fillstripe Color
                    For I = 0 To 200
                      Call Time1
                      Call Time2
                      Next
 end sub

 sub breathing
                A1 = Rx : A2 = Gx : A3 = Bx
                For Ll = 0 To 255
                  If A1 = 1 Or A2 = 1 Or A3 = 1 Then Exit For
                  If A1 > 1 Then Decr A1
                  If A2 > 1 Then Decr A2
                   If A3 > 1 Then Decr A3
                  R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time1
                Next

              For Ll = 0 To 255
               If A1 = Rx Or A2 = Gx Or A3 = Bx Then Exit For
               If A1 < Rx Then Incr A1
                If A2 < Gx Then Incr A2
                If A3 < Bx Then Incr A3
                R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time2
              Next
 end sub

 Sub Percolate_run
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = 0 To Jk
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
             Rb_clearcolors
             Reset Watchdog
         Next
 end sub

 sub percolate_return
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = Jk To 0 Step -1
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Waitms 1
             Rb_send
             Rb_clearcolors
             Reset Watchdog
         Next

 end sub



 Sub Snak_1_2_run

      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = 1 To Led Step 2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_return
      Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = Dvado To 0 Step -2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_run_rev
      Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_return_rev
      'Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

   Sub Snak_relax_run
     Rb_clearcolors
            R = Rx : G = Gx : B = Bx
          If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0
       For Nd = Led To Led -10 Step -1
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Led -11 To Led -20 Step -1
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
      Rb_send

      For N = 0 To Led
            Rb_shiftleft 0 , Led
              Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

  Sub Snak_relax_return
     Rb_clearcolors
           R = Rx : G = Gx : B = Bx
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0
       For Nd = 0 To 10
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = 11 To 21
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
      Rb_send

      For N = 0 To Led
            Rb_shiftright 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

   Sub Snak_rainbow
       For I = 0 To 23
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Jk = 10 + Bfd
          Kk = 11 + Bfd
          Lk = 20 + Bfd
       For Nd = Bfd To Jk
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Jk To Lk
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next

     Next

        Rb_send

      For N = 0 To Led
         If Rainbo = 0 Then Rb_rotateright 0 , Led
         If Rainbo = 1 Then Rb_rotateleft 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

    Sub Snak_rainbow_lp
       For I = 0 To 23
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Jk = 10 + Bfd
          Kk = 11 + Bfd
          Lk = 20 + Bfd
       For Nd = Bfd To Jk
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Jk To Lk
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next

     Next

        Rb_send

      For N = 0 To Led
         If Rainbo = 0 Then Rb_rotateright 0 , Led
         If Rainbo = 1 Then Rb_rotateleft 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

 Sub Snak_rainbow_bl
      Rb_clearcolors
   Rb_clearstripe
       For I = 0 To 23
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Lk = 20 + Bfd
       For Nd = Bfd To Lk
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
     Next
        Rb_send
           Call Time1
           Rb_rotateleft 0 , Led
             Rb_send
             Reset Watchdog
                    Rb_clearcolors
       Call Time2
        Reset Watchdog
 End Sub