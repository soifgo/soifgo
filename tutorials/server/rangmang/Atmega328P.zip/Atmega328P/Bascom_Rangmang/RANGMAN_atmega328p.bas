' ==============================================================================
' Developer: Saeid Moghadam
' Email: SSMQQMSS@gmail.com
' Project: SoifGo (Rangmang Controller)
' Hardware: ATmega328p (Supports up to 450 pixels)
' Protocol Specification (30 Inputs / Dynamic Command Length)
' ==============================================================================
' --- Data Packet Format ---
' Pattern: A(adr) D(mode) R(red) G(green) B(blue) S(start/delay1) E(end/delay2) M(memory/pixels)
' Example: A1D0R255G0B0S0E180M0
' --- [A] ADDRESS MODULE ---
' A1 to A98 : Specific Module Address
' A99        : Broadcast to All Modules
' --- [D0] SOLID COLOR MODE (Static Display) ---
' D00        : Activates Solid Color Mode
' R0   - R255 : Red Intensity
' G0   - G255 : Green Intensity
' B0   - B255 : Blue Intensity
' S0   - S450 : RGB Strip START Position for Colored Pixels
' E0   - E450 : RGB Strip END Position for Colored Pixels
' M0          : Preview Mode (Run without saving to EEPROM)
' M1          : Save current settings to Slot 1 Memory
' --- [D1 to D55] DANCE / EFFECT MODE ---
' D01  - D55  : Select Specific Dance/Light Effect
' D99        : Auto-Random Selection (Cycles through D01 to D55)
' R0   - R250 : Fixed Red   | R251 to R255 : Random Red Intensity
' G0   - G250 : Fixed Green | G251 to G255 : Random Green Intensity
' B0   - B250 : Fixed Blue  | B251 to B255 : Random Blue Intensity
' S0   - S999 : First Effect Delay (ms)
' E0   - E999 : Second Effect Delay (ms)
' M1   - M450 : Set Total Number of Active Dancing Pixels
' ==============================================================================

$regfile = "m328pdef.dat"
$crystal = 1105920
$prog &HFF , &HBE , &HCF , &HFE       '328
$hwstack = 40
$swstack = 16
$framesize = 32


Dim Ina As Bit      'external crystal 11059200
Config Watchdog = 1024
 Enable Interrupts
 $baud = 960
 Reset Watchdog
Ff:
'----[MAIN]---------------------------------------------------------------------
   Dim Danc , Dan , Dans As Byte
   Dim N , Nd , Ns , Nf , Jj , Led , S , Ii , I , T As Word
   Dim Ch , Ch0 , A1 , A2 , A3 As Byte
   Dim Text As String * 81
   Dim Trig , Trigf As String * 5
   Dim Trig2 As String * 5
   Dim Rq(99) , Gq(99) , Bq(99) As Byte
   Dim Rgb , Mmr , Mmg , Mmb As Byte
   Dim Tim1 , Tim2 , Tt1 , Tt2 , Ado , Ll , Adss , Adss2 , Adsm , Adsm2 As Word
   Dim Rr , Gg , Bb As Byte
   Dim Rx , Gx , Bx As Byte
   Dim Chc , Nnb , Mx , Rainbo As Bit
   Dim Jk , Kk , Lk As Word
   Dim Dvado As Word
  ''''''''''''''''''''''''''''''''''
  Dim Xfd , Yfd , Vfd , Bfd As Word


   Dim Memoclr As Byte
   Declare Sub Memclr       ' select first chann
   Declare Sub Chekm
   Declare Sub Time1
   Declare Sub Time2
   Readeeprom Ch0 , 1
   Readeeprom Dan , 2
   Readeeprom Rr , 3
   Readeeprom Gg , 4
   Readeeprom Bb , 5
   Readeeprom Led , 6
   Readeeprom Memoclr , 9
   Readeeprom Tim1 , 10
   Readeeprom Tim2 , 12
   Call Chekm
   If Ch0 > 98 Or Ch0 < 1 Then Ch0 = 1
   If Dan > 99 Then Dan = 0
   If Led > 990 Then Led = 990

    If Memoclr = 0 Or Memoclr > 1 Then
      Call Memclr
      Memoclr = 1
      Writeeeprom Memoclr , 9
    End If

  Declare Sub Modh
  Declare Sub Snak_run_slow
  Declare Sub Snak_return_slow
  Declare Sub Snak_run_fast
  Declare Sub Snak_return_fast
  Declare Sub Snak_run_slow_random
  Declare Sub Snak_return_slow_random
  Declare Sub Snak_run_fast_random
  Declare Sub Snak_return_fast_random
  Declare Sub Snak_runreturn_slow_random
  Declare Sub Half_snak_out_mid_slow
  Declare Sub Half_half_right_slow
  Declare Sub Half_half_left_slow
  Declare Sub Star_runreturn_slow
  Declare Sub Star_run_slow
  Declare Sub Star_run_fast
  Declare Sub Star_return_fast
  Declare Sub Snak_growup_slow
  Declare Sub Star_playful
  Declare Sub Snak_star_playful
  Declare Sub Star_fillers
  Declare Sub Movable_light
  Declare Sub Snak_runreturn_colored
  Declare Sub Star_diamonds_blink_slow
  Declare Sub Star_diamonds_blink_fast
  Declare Sub Star_diamonds_blink_faster
  Declare Sub Disco
  Declare Sub Fillstripe_color
  Declare Sub Breathing
  Declare Sub Percolate_run
  Declare Sub Percolate_return
  Declare Sub Snak_1_2_run
  Declare Sub Snak_1_2_return
  Declare Sub Snak_1_2_run_rev
  Declare Sub Snak_1_2_return_rev
  Declare Sub Snak_relax_run
  Declare Sub Snak_relax_return
  Declare Sub Snak_rainbow
 Declare Sub Snak_rainbow_lp
  Declare Sub Snak_rainbow_bl
   Danc = Dan

   Config Rainbow = 1 , Rb0_len = 450 , Rb0_port = Portd , Rb0_pin = 5
   Dim Color(3) As Byte
   R Alias Color(_base) : G Alias Color(_base + 1) : B Alias Color(_base + 2)
   Rb_selectchannel 0
   Rb_clearcolors
   Rb_clearstripe

   Reset Watchdog
 If Dan = 0 Then
   For I = 1 To 98
      Mmr = I + 100
      Mmg = I + 200
      Mmb = I + 300

      Readeeprom Rgb , Mmr
      Rq(i) = Rgb
      Readeeprom Rgb , Mmg
      Gq(i) = Rgb
      Readeeprom Rgb , Mmb
      Bq(i) = Rgb
      Reset Watchdog

      If Led > 0 And Led < 99 Then
            Reset Watchdog
            Adss = I * 4
            Adss = Adss + 396
            R = Rq(i) : G = Gq(i) : B = Bq(i)
           Adss2 = Adss + 2
            Readeeprom Adsm , Adss
             Readeeprom Adsm2 , Adss2
            For S = Adsm To Adsm2
               Reset Watchdog
               Rb_setcolor S , Color(1)
            Next

               Rb_send
      Else
         If Led = 999 Then
            Reset Watchdog
            R = Rr : G = Gg : B = Bb
            Rb_fillstripe Color
         End If
      End If

   Next
 Else
  Call Modh
 End If

 Config Serialin = Buffered , Size = 80 , Bytematch = 13
   Reset Watchdog
   Clear Serialin
   '''''''''''''''''''''''''''''dance subs'''''''''

   Echo On

   Echo Off
Do
  Main:
   Reset Watchdog
   If Ina = 1 Then Goto Red
  If Danc > 0 And Ina = 0 Then Call Modh
Loop
  Serial0charmatch:
  Input Text
  Ina = 1
Return


 Red:
 Ina = 0
  Text = Trim(text)
  Text = Ltrim(text)

  Reset Watchdog
  ''''''''''''''''''''''''''''''''''''''''''''ch
If Instr(text , "CH") > 0 Then
      Dim Pos_equal As Byte
      Pos_equal = Instr(text , "=")
      If Pos_equal > 3 Then
         Dim Len_old As Byte
         Len_old = Pos_equal - 3
         Trig = Mid(text , 3 , Len_old)

         If Ch0 = Val(trig) Then
            Dim Start_new As Byte
            Start_new = Pos_equal + 1
            Trig2 = Mid(text , Start_new)
            Ch = Val(trig2)
            If Ch > 0 And Ch < 99 Then
               Ch0 = Ch
               Writeeeprom Ch0 , 1
               Print "New Address=" ; Ch0
            End If
         End If
      End If
   End If
   '''''''''''''''''''''''''''''''''''''''''
   '''''''''''''''''''''''''''''''''''''''''
   Hh:
   '''''''''''''''''''''''''''''
     Dim S0 , N0 As Byte
    For N0 = 1 To 32
     Reset Watchdog
         S0 = N0 + 1
       Trig = Mid(text , N0 , 1 )
     '''''''''''''''''''''''''''''''''''''''''''A
     If Instr(trig , "A") > 0 Then
         Trigf = Mid(text , S0 , 2)
       If Trigf <> "" Then
          If Val(trigf) > 0 And Val(trigf) < 100 Then Ch = Val(trigf)
       End If
     End If
     '''''''''''''''''''''''''''''''''
         If Ch = Ch0 Or Ch = 99 Then
             ''''''''''''''''''''''''''''''''''''Dance
           If Instr(trig , "D") > 0 Then
              Trigf = Mid(text , S0 , 2)
             If Val(trigf) >= 0 And Val(trigf) < 100 Then
              Danc = Val(trigf)
              Dan = Danc
             End If
           End If
           '''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''''''''RGBM
                       If Instr(trig , "R") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 256 Then
                           R = Val(trigf)
                           Rr = R
                          End If
                       End If
                       If Instr(trig , "G") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                           If Val(trigf) >= 0 And Val(trigf) < 256 Then
                            G = Val(trigf)
                            Gg = G
                           End If
                       End If
                       If Instr(trig , "B") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                           If Val(trigf) >= 0 And Val(trigf) < 256 Then
                            B = Val(trigf)
                            Bb = B
                           End If
                       End If
                       If Instr(trig , "M") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Led = Val(trigf)
                       End If
                       '''''''''''''''''''''''''''''''
              Reset Watchdog

            If Dan = 0 Then
            ''''''''''''''''''''''''''pixel Start  End
                       If Instr(trig , "S") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Ns = Val(trigf)
                       End If
                       If Instr(trig , "E") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Nf = Val(trigf)
                       End If
                '''''''''''''''''''''''''''''''''''''''''''''''''
            Else
               ''''''''''''''''''''''''''Time Start  End
                       If Instr(trig , "S") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Tim1 = Val(trigf)
                       End If
                       If Instr(trig , "E") > 0 Then
                          Trigf = Mid(text , S0 , 3)
                          If Val(trigf) >= 0 And Val(trigf) < 1000 Then Tim2 = Val(trigf)
                       End If
                       ''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If
         End If
    Next

               If Dan >= 0 And Dan < 100 Then Writeeeprom Dan , 2
            If Dan = 0 Then
               If Led > 0 And Led < 99 Then
                  Writeeeprom Led , 6
                  Adss = Led * 4
                  Adss = Adss - 2
                   Adss = 790 - Adss
                  Writeeeprom Ns , Adss
                    Adss = Adss + 2
                  Writeeeprom Nf , Adss
                  Mmr = 199 - Led
                  Mmg = 299 - Led
                  Mmb = 399 - Led
                  Writeeeprom Rr , Mmr
                  Writeeeprom Gg , Mmg
                  Writeeeprom Bb , Mmb
                   Reset Watchdog
                  R = Rr : G = Gg : B = Bb
                  For I = Ns To Nf
                     Reset Watchdog
                     Rb_setcolor I , Color(1)
                  Next
                     Rb_send
                     Waitms 1
               Else
               Select Case Led
                  Case 0:
                     R = Rr : G = Gg : B = Bb
                     For I = Ns To Nf
                        Reset Watchdog
                        Rb_setcolor I , Color(1)
                     Next
                       Rb_send
                        Waitms 1
                  Case 996:
                      Call Memclr
                  Case 997:
                     Rb_clearstripe
                     Waitms 100
                  Case 998:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 100
                  Case 999:
                     R = Rr : G = Gg : B = Bb
                     Rb_fillstripe Color
                     Waitms 1
                     Writeeeprom Rr , 3
                     Writeeeprom Gg , 4
                     Writeeeprom Bb , 5
                     Led = 999
                     Writeeeprom Led , 6
               End Select
               End If
               Reset Watchdog
            Else
              If Led < 1 Then Led = 1
              If Led > 999 Then Led = 999
               Call Chekm
               If Danc > 0 And Danc < 100 Then
                  Writeeeprom Rr , 3
                  Writeeeprom Gg , 4
                  Writeeeprom Bb , 5
                  Writeeeprom Led , 6
                  Writeeeprom Tim1 , 10
                  Writeeeprom Tim2 , 12
                  Reset Watchdog
               End If
            End If
'   '''''''''''''''''''''''''''''''''''


        'Print "a=" ; Ch ; "d=" ; Danc ; "r=" ; Rr ; "g=" ; Gg ; "b=" ; _
        ' Bb ; "s=" ; Ns ; "e=" ; Nf ; "m=" ; Led
      Text = ""
      Trig = ""
       Trigf = ""
        Trig2 = ""
      Ch = ""
      Reset Watchdog
      Clear Serialin
Goto Main

Sub Modh

   If Led = 0 Then Led = 1
   If Danc = 99 Then
        Reset Watchdog
         Dans = Rnd(55)
   Else
      Dans = Danc - 1

   End If

  If Rr < 251 Then
      Rx = Rr
   Else
      Rx = 251
      Select Case Rr
         Case 251
            Rx = Rnd(15)
         Case 252
            Rx = Rnd(30)
         Case 253
            Rx = Rnd(60)
         Case 254
            Rx = Rnd(120)
         Case 255
            Rx = Rnd(250)
      End Select
      R = Rx
   End If

   If Gg < 251 Then
      Gx = Gg
   Else
      Gx = 251
      Select Case Gg
         Case 251
            Gx = Rnd(15)
         Case 252
            Gx = Rnd(30)
         Case 253
            Gx = Rnd(60)
         Case 254
            Gx = Rnd(120)
         Case 255
            Gx = Rnd(250)
      End Select
      G = Gx
   End If

   If Bb < 251 Then
      Bx = Bb
   Else
      Bx = 251
      Select Case Bb
         Case 251
            Bx = Rnd(15)
         Case 252
            Bx = Rnd(30)
         Case 253
            Bx = Rnd(60)
         Case 254
            Bx = Rnd(120)
         Case 255
            Bx = Rnd(250)
      End Select
      B = Bx
   End If

  Select Case Dans

  Case 0 : Call Snak_run_slow
  Case 1 : Call Snak_return_slow
  Case 2:
  Call Snak_run_slow
  Call Snak_return_slow
  Case 3 : Call Snak_run_fast
  Case 4 : Call Snak_return_fast
  Case 5:
  Call Snak_run_fast
  Call Snak_return_fast

  Case 6 : Call Snak_run_slow_random
  Case 7 : Call Snak_return_slow_random
  Case 8:
  Call Snak_run_slow_random
  Call Snak_return_slow_random
  Case 9 : Call Snak_run_fast_random
  Case 10 : Call Snak_return_fast_random
  Case 11:
  Call Snak_run_fast_random
  Call Snak_return_fast_random
  Case 12 : Call Snak_runreturn_slow_random
  Case 13 :
  Nnb = 0
  Call Half_snak_out_mid_slow
  Case 14 :
  Nnb = 1
  Call Half_snak_out_mid_slow
  Case 15 :
   Call Half_snak_out_mid_slow
   Toggle Nnb
      Goto Modh
  Case 16 : Call Half_half_right_slow
  Case 17 : Call Half_half_left_slow
  Case 18 :
  Mx = 0
   Call Star_run_slow
   Case 19 :
   Mx = 1
    Call Star_run_slow
  Case 20 : Call Star_runreturn_slow
  Case 21 : Call Star_run_fast
  Case 22 : Call Star_return_fast
  Case 23:
  Call Star_run_fast
  Call Star_return_fast
  Case 24 : Call Snak_growup_slow
  Case 25 : Call Star_playful
  Case 26 : Call Snak_star_playful
  Case 27 : Call Star_fillers
  Case 28 : Call Movable_light
  Case 29 : Call Snak_runreturn_colored
  Case 30 : Call Star_diamonds_blink_slow
  Case 31 : Call Star_diamonds_blink_fast
  Case 32 : Call Star_diamonds_blink_faster
  Case 33 : Call Disco
  Case 34 : Call Fillstripe_color
  Case 35 : Call Breathing
  Case 36 : Call Percolate_run
  Case 37 : Call Percolate_return
  Case 38 :
   Call Percolate_run
   Call Percolate_return
  Case 39 : Call Snak_1_2_run
  Case 40 : Call Snak_1_2_return
   Case 41 :
    Call Snak_1_2_run
    Call Snak_1_2_return
  Case 42 : Call Snak_1_2_run_rev
  Case 43 : Call Snak_1_2_return_rev
   Case 44 :
    Call Snak_1_2_run_rev
    Call Snak_1_2_return_rev
  Case 45 : Call Snak_relax_run
  Case 46 : Call Snak_relax_return
   Case 47 :
    Call Snak_relax_run
    Call Snak_relax_return
    Case 48 :
    Rainbo = 0
     Call Snak_rainbow
  Case 49 :
  Rainbo = 1
   Call Snak_rainbow
   Case 50 :
   Rainbo = 0
    Call Snak_rainbow
      Rainbo = 1
    Call Snak_rainbow

        Case 51 :
    Rainbo = 0
     Call Snak_rainbow_lp
  Case 52 :
  Rainbo = 1
   Call Snak_rainbow_lp
   Case 53 :
   Rainbo = 0
    Call Snak_rainbow_lp
      Rainbo = 1
    Call Snak_rainbow_lp
     Case 54 : Call Snak_rainbow_bl
  End Select
End Sub



Sub Chekm
    If Tim1 > 999 Or Tim1 < 1 Then Tim1 = 1
    If Tim2 > 999 Or Tim2 < 1 Then Tim2 = 1
End Sub

Sub Time1
   Call Chekm
   For Tt1 = 0 To Tim1
      Reset Watchdog
      Waitms 1
      If Ina = 1 Then Exit For
   Next
     If Ina = 1 Then Goto Red
End Sub

Sub Time2
   Call Chekm
   For Tt2 = 0 To Tim2
      Reset Watchdog
      Waitms 1
      If Ina = 1 Then Exit For
   Next
   If Ina = 1 Then Goto Red
End Sub

Sub Memclr
                     R = 0
                     Print "   "
                      Print " Rangmang Wait "
                     For Ii = 0 To 800
                        Writeeeprom R , Ii
                        Reset Watchdog
                     Next
                      Print " Clear :) "
                     Rb_clearstripe
End Sub



''''''''''''''efects
   Sub Snak_run_slow

       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led

          Rb_setcolor Nd , Color(1)
          Call Time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led

           Rb_setcolor Nd , Color(1)
           Call Time2
           Rb_send
        Next
     End Sub

    Sub Snak_return_slow

       R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -1

          Rb_setcolor Nd , Color(1)
          Call Time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = Led To 0 Step -1

           Rb_setcolor Nd , Color(1)
           Call Time2
           Rb_send
        Next
     End Sub

     Sub Snak_run_fast       '
       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
          Call Time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led Step 5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
           Call Time2
           Rb_send
        Next
     End Sub

     Sub Snak_return_fast
       R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
          Call Time1
          Rb_send
       Next

        R = 0 : G = 0 : B = 0
        For Nd = Led To 0 Step -5
          Xfd = Nd + 1
          Yfd = Nd + 2
          Vfd = Nd + 3
          Bfd = Nd + 4
          Rb_setcolor Nd , Color(1)
          Rb_setcolor Xfd , Color(1)
          Rb_setcolor Yfd , Color(1)
          Rb_setcolor Vfd , Color(1)
          Rb_setcolor Bfd , Color(1)
           Call Time2
           Rb_send
        Next
      End Sub

     Sub Snak_run_slow_random
            For Nd = 0 To Led

             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             Call Time2
             Rb_send
           Next
           Rb_clearstripe
      End Sub
      Sub Snak_return_slow_random
            For Nd = Led To 0 Step -1
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
           Rb_clearstripe
    End Sub

    Sub Snak_run_fast_random
            For Nd = 0 To Led Step 5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               Xfd = Nd + 1
               Yfd = Nd + 2
               Vfd = Nd + 3
               Bfd = Nd + 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
               Rb_send
               Call Time1
            Next
            R = 0 : G = 0 : B = 0
            For Nd = 0 To Led Step 5
               Xfd = Nd + 1
               Yfd = Nd + 2
               Vfd = Nd + 3
               Bfd = Nd + 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
               Rb_send
               Call Time2
            Next
            Rb_clearstripe
      End Sub
      Sub Snak_return_fast_random
            For Nd = Led To 4 Step -5
             Jj = Nd Mod 2
             If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
               Xfd = Nd - 1
               Yfd = Nd - 2
               Vfd = Nd - 3
               Bfd = Nd - 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
             Call Time1
             Rb_send
            Next
           R = 0 : G = 0 : B = 0
            For Nd = Led To 4 Step -5
               Xfd = Nd - 1
               Yfd = Nd - 2
               Vfd = Nd - 3
               Bfd = Nd - 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
             Call Time2
             Rb_send
            Next
            Rb_clearstripe
      End Sub

    Sub Snak_runreturn_slow_random
                   For Nd = Led To 0 Step -1

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   Call Time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftright 0 , Led
             Call Time2
             Rb_send
           Next

            For Nd = 0 To Led

                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   Call Time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
    End Sub


     Sub Half_snak_out_mid_slow
                R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         If Nnb = 0 Then
         For Nd = 0 To Jk
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
         Next

         Else

         For Nd = Jk To 0 Step -1
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
         Next

         End If

       End Sub


      Sub Half_half_right_slow
          Rb_clearcolors
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = 0 To Jk
               Kk = Jk + Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
            Call Time1
             Rb_send
         Next

       End Sub

    Sub Half_half_left_slow
        Rb_clearcolors
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = Jk To 0 Step -1
               Kk = Jk + Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
            Call Time1
             Rb_send
         Next

       End Sub

   Sub Star_run_slow

         If Chc = 0 Then
           Ado = Led
           Chc = 1
         End If
         If Ado = 1 Then Chc = 0

         For Nd = 0 To Ado Step 2
              If Mx = 0 Then
                 R = Rx : G = Gx : B = Bx
               Else
                 R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
              End If
              Dvado = Nd + 1
             Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
             Rb_send
             Call Time1
             Rb_clearcolors
         Next
      If Mx = 0 Then
          R = 222 : G = 222 : B = 222
         Else
          R = Rnd(222) : G = Rnd(222) : B = Rnd(222)
      End If




         If Ado > 10 Then

              Dvado = Ado / 10
            For Nd = Ado To Ado + Dvado
                Rb_setcolor Nd , Color(1)
            Next
           Else
           Rb_setcolor Ado , Color(1)
          End If
          Rb_send
          Call Time2
        If Chc = 1 Then
          If Ado > 10 Then
             Ado = Ado - Dvado
          Else
             Decr Ado
          End If
        End If

   End Sub


   Sub Star_runreturn_slow
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
              Dvado = Nd + 1
             Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
               Dvado = Nd + 2
              Rb_setcolor Dvado , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next         'call time1
       For Nd = Led To 0 Step -2
              Dvado = Nd + 1
              Rb_setcolor Nd , Color(1)
              Rb_setcolor Dvado , Color(1)
              Dvado = Nd + 2
              Rb_setcolor Dvado , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   End Sub
   Sub Star_run_fast
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 5
               Xfd = Nd + 1
               Yfd = Nd + 2
               Vfd = Nd + 3
               Bfd = Nd + 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time1
          Rb_clearcolors
       Next
     End Sub
     Sub Star_return_fast       'call time1
       For Nd = Led To 5 Step -5
               Xfd = Nd - 1
               Yfd = Nd - 2
               Vfd = Nd - 3
               Bfd = Nd - 4
               Rb_setcolor Nd , Color(1)
               Rb_setcolor Xfd , Color(1)
               Rb_setcolor Yfd , Color(1)
               Rb_setcolor Vfd , Color(1)
               Rb_setcolor Bfd , Color(1)
         Rb_setcolor Nd , Color(1)
         Rb_send
         Call Time2
         Rb_clearcolors
       Next
   End Sub
Sub Snak_growup_slow
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send

          If T < Led Then T = T + 5
          If T => Led Then T = 1

           For N = 1 To Led -t
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -3 Step -1
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -t

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
End Sub

Sub Star_playful
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To 4
             Rb_setcolor Nd , Color(1)
             Next
             Rb_send
           Yfd = Rnd(5)
          If T < Led Then T = T + Yfd
          If T => Led Then T = 1

           For N = 1 To Led -t
             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next

           Xfd = Rnd(5)
           For Nd = Led -1 To Led -xfd Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next
              Vfd = Rnd(t)
           For N = 1 To Led -vfd

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
End Sub

Sub Snak_star_playful
                If Led < 22 Then Led = 22
           Dim Pp As Byte
           Pp = Rnd(10) : If Pp = 0 Then Pp = 1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To Pp
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next

           Pp = Rnd(10) : If Pp = 0 Then Pp = 1
          If T < Led Then T = T + 1
          If T => Led Then T = 1
              T = Rnd(t)
              T = T + Pp
              If T = 0 Then T = 1
           For N = 1 To Led -t Step Pp
              If N > 0 Then
             Rb_shiftright 0 , Led
             Rb_send
             End If
             Call Time1

           Next


           For Nd = Led -1 To Led -t Step -3
           If Nd > 0 Then
             Rb_setcolor Nd , Color(1)
             Rb_send
           End If
            Reset Watchdog
             Next

           Pp = Rnd(10) : If Pp = 0 Then Pp = 3
           For N = 1 To Led -t Step Pp
              If N > 0 Then
             Rb_shiftleft 0 , Led
             Rb_send
             End If
             Call Time2
           Next

       ''''''''''''''''''''''''''''''''''''''''
           Pp = Rnd(10) : If Pp = 0 Then Pp = 1



           Pp = Rnd(10) : If Pp = 0 Then Pp = 1
          If T < Led Then T = T + 1
          If T => Led Then T = 1
              T = Rnd(t)
              T = T + Pp
              If T = 0 Then T = 1
              Dim Jd , Md As Word
               Md = Rnd(led) : If Md < T Then Md = T + 1
           For N = 1 To Md -t Step Pp
           Jd = Led - Pp
              If N > 0 Then
             Rb_setcolor N , Color(1)
             Rb_send
             End If
             If Jd > 0 Then
             Rb_setcolor Jd , Color(1)
             Rb_send
             End If
             Call Time1

           Next


           For Nd = Led -t To Led -1 Step -3
           If Nd > 0 Then
             Rb_setcolor Nd , Color(1)
             Rb_send
           End If
             Reset Watchdog
             Next

           Pp = Rnd(10) : If Pp = 0 Then Pp = 3
           For N = Led -t To 1 Step Pp
              If N > 0 Then
             Rb_shiftright 0 , Led
             Rb_send
             End If
             Call Time2
           Next

            For Nd = 1 To Pp
             Rb_setcolor Nd , Color(1)
             Rb_send
             Next
End Sub
 Sub Star_fillers
             If Ado < Led Then Ado = Ado + 1
            If Ado = Led Then Ado = 1
           R = Rx : G = Gx : B = Bx
           For Nd = 1 To Ado Step 4
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next



           For N = 1 To Led -ado Step -4

             Rb_shiftright 0 , Led
             Call Time1
             Rb_send
           Next


           For Nd = Led -1 To Led -ado Step -5
             Rb_setcolor Nd , Color(1)
             Rb_send
             Reset Watchdog
             Next

           For N = 1 To Led -ado

             Rb_shiftleft 0 , Led
             Call Time2
             Rb_send
           Next
 End Sub

 Sub Movable_light
           Xfd = Rnd(rx) : Yfd = Rnd(gx) : Vfd = Rnd(bx)
         For Nd = 0 To Led
             R = 222 : G = 222 : B = 222
             Jk = Nd + 1
             Kk = Nd + 2
             Lk = Nd + 3
             Rb_setcolor Lk , Color(1)
             Rb_setcolor Kk , Color(1)
             Rb_setcolor Jk , Color(1)
              R = Xfd : G = Yfd : B = Vfd
             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
         Next
           Xfd = Rnd(rx) : Yfd = Rnd(gx) : Vfd = Rnd(bx)
         For Nd = Led To 0 Step -1

             R = 222 : G = 222 : B = 222
             Jk = Nd + 1
             Kk = Nd + 2
             Lk = Nd + 3
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Jk , Color(1)
             Rb_setcolor Kk , Color(1)
              R = Xfd : G = Yfd : B = Vfd
             Rb_setcolor Lk , Color(1)
             Call Time2
             Rb_send
         Next
 End Sub

 Sub Snak_runreturn_colored
                R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = 0 To Led

             Rb_setcolor Nd , Color(1)
             Call Time1
             Rb_send
         Next
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = Led To 0 Step -1

             Rb_setcolor Nd , Color(1)
             Call Time2
             Rb_send
         Next
 End Sub
 Sub Star_diamonds_blink_slow
                         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Call Time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Call Time2
                   Rb_send
 End Sub
  Sub Star_diamonds_blink_fast
               R = Rx : G = Gx : B = Bx
                   Call Time1
                   Call Time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors
 End Sub

 Sub Star_diamonds_blink_faster
                    R = Rx : G = Gx : B = Bx
                   Call Time1
                   Call Time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   Rb_send
                   Rb_clearcolors

 End Sub

 Sub Disco
                   R = Rx : G = Gx : B = Bx
               For I = 0 To Led
                   Call Time1
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
               Next
                  Rb_send
                  R = 0 : G = 0 : B = 0
               For I = 0 To Led
                   Call Time2
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)

               Next
                  Rb_send
 End Sub

 Sub Fillstripe_color
                  R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                    Rb_fillstripe Color
                    For I = 0 To 200
                      Call Time1
                      Call Time2
                      Next
 End Sub

 Sub Breathing
                A1 = Rx : A2 = Gx : A3 = Bx
                For Ll = 0 To 255
                  If A1 = 1 Or A2 = 1 Or A3 = 1 Then Exit For
                  If A1 > 1 Then Decr A1
                  If A2 > 1 Then Decr A2
                   If A3 > 1 Then Decr A3
                  R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time1
                Next

              For Ll = 0 To 255
               If A1 = Rx Or A2 = Gx Or A3 = Bx Then Exit For
               If A1 < Rx Then Incr A1
                If A2 < Gx Then Incr A2
                If A3 < Bx Then Incr A3
                R = A1 : G = A2 : B = A3
                    Rb_fillstripe Color
                      Call Time2
              Next
 End Sub

 Sub Percolate_run
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = 0 To Jk
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Call Time1
             Rb_send
             Rb_clearcolors
             Reset Watchdog
         Next
 End Sub

 Sub Percolate_return
           R = Rx : G = Gx : B = Bx
           Jk = Led / 2
         For Nd = Jk To 0 Step -1
               Kk = Led - Nd
             Rb_setcolor Nd , Color(1)
             Rb_setcolor Kk , Color(1)
             Waitms 1
             Rb_send
             Rb_clearcolors
             Reset Watchdog
         Next

 End Sub



 Sub Snak_1_2_run

      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = 1 To Led Step 2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_return
      Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = Dvado To 0 Step -2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_run_rev
      Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

  Sub Snak_1_2_return_rev
      'Dvado = Led + 1
      Rb_clearcolors
            R = Rx : G = Gx : B = Bx
       For Nd = Led To 0 Step -2
          Rb_setcolor Nd , Color(1)
           Rb_send
          Call Time1
       Next
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
        If R < 10 Then R = 10
        If G < 10 Then G = 10
        If B < 10 Then B = 10
       For Nd = 0 To Led Step 2
          Rb_setcolor Nd , Color(1)
          Rb_send
          Call Time2
       Next
 End Sub

   Sub Snak_relax_run
     Rb_clearcolors
            R = Rx : G = Gx : B = Bx
          If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0
       For Nd = Led To Led -10 Step -1
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Led -11 To Led -20 Step -1
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
      Rb_send

      For N = 0 To Led
            Rb_shiftleft 0 , Led
              Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

  Sub Snak_relax_return
     Rb_clearcolors
           R = Rx : G = Gx : B = Bx
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0
       For Nd = 0 To 10
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = 11 To 21
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
      Rb_send

      For N = 0 To Led
            Rb_shiftright 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

   Sub Snak_rainbow
       For I = 0 To 23
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Jk = 10 + Bfd
          Kk = 11 + Bfd
          Lk = 20 + Bfd
       For Nd = Bfd To Jk
           R = Xfd + R : G = Yfd + G : B = Vfd + B
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Jk To Lk
           R = R -xfd : G = G -yfd : B = B -vfd
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next

     Next

        Rb_send

      For N = 0 To Led
         If Rainbo = 0 Then Rb_rotateright 0 , Led
         If Rainbo = 1 Then Rb_rotateleft 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

    Sub Snak_rainbow_lp
       For I = 0 To 23
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Jk = 10 + Bfd
          Kk = 11 + Bfd
          Lk = 20 + Bfd
       For Nd = Bfd To Jk
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
       For Nd = Jk To Lk
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next

     Next

        Rb_send

      For N = 0 To Led
         If Rainbo = 0 Then Rb_rotateright 0 , Led
         If Rainbo = 1 Then Rb_rotateleft 0 , Led
             Call Time1
             Rb_send
             Reset Watchdog
      Next

        Reset Watchdog
 End Sub

 Sub Snak_rainbow_bl
      Rb_clearcolors
   Rb_clearstripe
       For I = 0 To 23
        R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
            R = 0 : G = 0 : B = 0

          Bfd = 20 * I
          Lk = 20 + Bfd
       For Nd = Bfd To Lk
         R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         If R > 10 Then Xfd = R / 10
         If G > 10 Then Yfd = G / 10
         If B > 10 Then Vfd = B / 10
          Rb_setcolor Nd , Color(1)
           Reset Watchdog
       Next
     Next
        Rb_send
           Call Time1
           Rb_rotateleft 0 , Led
             Rb_send
             Reset Watchdog
                    Rb_clearcolors
       Call Time2
        Reset Watchdog
 End Sub