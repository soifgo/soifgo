 ' Saeid20985
 'Rangmang atmega 8_ 255 pixel
 '22 input

 'dance
 'ch__mod_red_green_blue_time1_time2_pixel
 'address or ch  01 to 98   and 99  for all     parallel
 'mod  00 for solid color  + memori
 'mod 01 to 13   dance
 'red 000 to 255
 'green 000 to 255
 'blue 000 to 255
 ' time1  000 ms to 999 ms for dance
  ' time2  000 ms to 999 ms for dance
  'pixel  001 to 255

  'ch   mod    red    green     blue    time1     time2      pixel
  '00  00       000    000      000     000         000         000
  '0000000000000000000000

  'solid color
  'ch__mod_red_green_blue_start pixel_end pixel_memori

 'address or ch  01 to 98   and 99  for all     parallel
 'mod  00 for solid color  + memori
 'mod 01 to 13   dance
 'red 000 to 255
 'green 000 to 255
 'blue 000 to 255
 'start pixel 000 to 255 for solid color mod
  'end  pixel  000 to 255 for solid color mod
  ' memori save 001  to 010     000 = no memori

  'ch   mod    red    green     blue    start    end      memo
  '00  00       000    000      000     000      000      000
  '0000000000000000000000


$regfile = "m8adef.dat"
$crystal = 2000000                                 'external crystal 11059200
Config Watchdog = 2048
Start Watchdog
Reset Watchdog
ENABLE INTERRUPTS
Ff:
'----[MAIN]---------------------------------------------------------------------
Dim Danc , Dan As Byte
Dim N , Nd , Ndn  , Ns , Nf , Jj , Led , S As Byte
Dim I , Ch , Ch0 As Byte
Dim Text As String *22
Dim Trig As String * 3
Dim Rq(11) , Gq(11) , Bq(11) , Ads(21) As Byte
Dim Adss , Adss2 , Rgb , Mmr , Mmg , Mmb As Byte
Dim Tim1 , Tim2,tt1,tt2 As Word
Dim Rr , Gg , Bb As Byte
Dim Rx , Gx , Bx,bb4 As Byte
Dim Chc  As Bit

                                          ' select first chann
Declare Sub Chekm
Declare Sub red
Declare Sub time1
Declare Sub time2
 Readeeprom Ch0 , 1
  Waitms 1
 Readeeprom Dan , 2
  Waitms 1
 Readeeprom Rr , 3
  Waitms 1
 Readeeprom Gg , 4
  Waitms 1
 Readeeprom Bb , 5
  Waitms 1
 Readeeprom Led , 6
  Waitms 1
 Readeeprom Tim1 , 67
  Waitms 1
 Readeeprom Tim2 , 80
  Waitms 1
     call chekm
  If Ch0 > 98 Or Ch0 <1 Then Ch0 = 1
 If Dan > 99 Then Dan = 0
 If Led = 0 Then Led = 1

  For I = 1 To 10
     Mmr = I + 10
    Mmg = I + 20
    Mmb = I + 30

    Readeeprom Rgb , Mmr
    Waitms 1
    Rq(i) = Rgb
     Readeeprom Rgb , Mmg
    Waitms 1
    Gq(i) = Rgb
     Readeeprom Rgb , Mmb
     Waitms 1
     Bq(i) = Rgb
     Reset Watchdog
  Next

     Reset Watchdog

  For I = 41 To 60
     Readeeprom Adss , I
     Waitms 1
     Ads(i -40) = Adss
     Reset Watchdog
  Next

  Danc = Dan
'Config Rainbow = 1,rgb=4 , Rb0_len =100 , Rb0_port = Portd , Rb0_pin = 5
Config Rainbow = 1, Rb0_len =255 , Rb0_port = Portd , Rb0_pin = 5
'Config Rainbow = 1 , Rb0_len =100 , Rb0_port = Portd , Rb0_pin = 2  'old version
'Dim Color(4) As Byte
Dim Color(3) As Byte
R Alias Color(_base) : g Alias Color(_base + 1) : b Alias Color(_base + 2)
'R Alias Color(_base) : G Alias Color(_base + 1) : B Alias Color(_base + 2): W alias color(_base + 3)

'w=1
Rb_selectchannel 0

 Enable Interrupts

Rb_clearcolors

Config Portb.4 = Input
Ddrb.4 = 0 : Portb.4 = 1

      If Dan = 0 Then

        For I = 1 To 10
                  Reset Watchdog
                    Adss = I * 2
                    Adss = Adss - 1
                    Adss2 = I * 2
                For S = Ads(adss) To Ads(adss2)
                        Reset Watchdog
                         R = Rq(i) : G = Gq(i) : B = Bq(i)
                         Rb_setcolor S , Color(1)
                         Waitms 1
                         Rb_send
                Next
        Next
      End If

   $baud =1764
On Urxc ur0
Enable Urxc
 enable Interrupts


Main:
        Reset Watchdog
        If Danc > 0 Then Goto Modh
        if pinb.4=1 then
                 bb4=0
            else
                 if bb4<200 then incr bb4
         end if

Goto Main


ur0:
 text=text+chr(udr)
if   udr=13 then  call red
return



sub red
 disable Interrupts
 text=mid(text,1,22)

 if len(text)=2 or len(text)=22  then  print text

 Trig = Mid(text , 1 , 2)
   Ch = Val(trig)

   if ch<0 or ch>99 then goto oute

  If bb4=200  and ch>0 and ch<100  Then
      Ch0 = ch
      Writeeeprom Ch0 , 1
      waitms 10
      Print " CH" ; Ch0
end if

if ch=ch0 and len(text)=22 then
            ''''''''''''''''''''''''''''''''''
           Trig = Mid(text , 3 , 2)
           Danc = Val(trig)
           Chc = 0
           Dan = Danc
           if danc>13 then dan=13
           Trig = Mid(text , 5 , 3)
           R = Val(trig)
           Rr = R
           Trig = Mid(text , 8 , 3)
           G = Val(trig)
           Gg = G
           Trig = Mid(text , 11 , 3)
           B = Val(trig)
           Bb = B
           Trig = Mid(text , 20 , 3)
           Led = Val(trig)




      If Dan = 0 Then
            Trig = Mid(text , 14 , 3)
            Ns = Val(trig)
            Trig = Mid(text , 17 , 3)
            Nf = Val(trig)

          If Led > 0 and led<11 Then
             Adss = Led * 2
             Adss = Adss + 39
             Writeeeprom Ns , Adss
             Adss = Led * 2
             Adss = Adss + 40
             Writeeeprom Nf , Adss
             Mmr = Led + 10
             Mmg = Led + 20
             Mmb = Led + 30
             Writeeeprom Rr , Mmr
             Writeeeprom Gg , Mmg
             Writeeeprom Bb , Mmb

                 R = Rr : G = Gg : B = Bb
               For I = Ns To Nf
                   Reset Watchdog
                   Rb_setcolor I , Color(1)
                   Rb_send
                   Waitms 1
               Next
          end if
           select case led
            case 0:
                               R = Rr : G = Gg : B = Bb
              For I = Ns To Nf
                Reset Watchdog
                Rb_setcolor I , Color(1)
                Rb_send
                 Waitms 1
              Next
              case 209:
                 r=0
                For I = 1 To 81
                  Writeeeprom r , i
                  Waitms 1
                Next
               goto ff
               case 136:
                goto ff
           end select


      Else


            Trig = Mid(text , 14 , 3)
            Tim1 = Val(trig)
            Trig = Mid(text , 17 , 3)
            Tim2 = Val(trig)
                call chekm
            if danc<15 then
                 Writeeeprom Dan , 2
                 Writeeeprom Rr , 3
                 Writeeeprom Gg , 4
                 Writeeeprom Bb , 5
                 Writeeeprom Led , 6
                 Writeeeprom Tim1 , 67
                 Writeeeprom Tim2 , 80
          end if
      End If

     If Led = 0 And Dan > 0 Then Led = 1
  End If

text=""
 Enable Interrupts
    end sub
oute:
text=""
 Enable Interrupts
Goto Main

Modh:
 If Danc = 13 Then
      Dan = Rnd(13)
      if dan>13 then dan=1
       if dan<1 then dan=13
 End If

  If Rr > 3  Then
       Rx = Rr
  Else
     rx=1
     Select Case Rr
       Case 1
         Rx = Rnd(50)
       Case 2
         Rx = Rnd(100)
       Case 3
         Rx = Rnd(250)
     End Select
      R = Rx
  End If

  If Gg > 3  Then
       Gx = Gg
  Else
     gx=1
    Select Case Gg
      Case 1
       Gx = Rnd(34)
      Case 2
       Gx = Rnd(68)
      Case 3
       Gx = Rnd(170)
    End Select
       G = Gx
  End If

   If Bb > 3  Then
      Bx = Bb
   Else
      bx=1
     Select Case Bb
      Case 1
       Bx = Rnd(34)
      Case 2
       Bx = Rnd(68)
      Case 3
       Bx = Rnd(170)
     End Select
     B = Bx
   End If

  Select Case Dan

     Case 1:

       R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led
          Reset Watchdog
          Rb_setcolor Nd , Color(1)
          call time1
          Rb_send
       Next
        R = 0 : G = 0 : B = 0
        For Nd = 0 To Led
           Reset Watchdog
           Rb_setcolor Nd , Color(1)
           call time2
           Rb_send
        Next
     Case 2:
         R = Rx : G = Gx : B = Bx
       For Nd = 0 To Led
          Reset Watchdog
          Rb_setcolor Nd , Color(1)
          Rb_send
          call time1
          Rb_clearcolors
       Next                                                 'call time1
       For Nd = Led To 0 Step -1
         Reset Watchdog
         Rb_setcolor Nd , Color(1)
         Rb_send
         call time2
         Rb_clearcolors
       Next
     Case 3:
        I = Led
        Jj = Led / 2
       For Nd = 0 To Jj
         Reset Watchdog
         R = Rx : G = Gx : B = Bx
         Rb_setcolor Nd , Color(1)
         Waitus 10
         Rb_send
         Decr I
         Rb_setcolor I , Color(1)
         call time1
         Rb_send
       Next
          call time2
         Rb_clearcolors
      Case 4:
        Jj = Led / 2
         I = Jj
         For Nd = Jj To Led
              Reset Watchdog
             R = Rx : G = Gx : B = Bx
             Rb_setcolor Nd , Color(1)
            call time1
             Rb_send
            Decr I
             Rb_setcolor I , Color(1)
            call time2
             Rb_send
         Next
            call time1
            call time2
            Rb_clearcolors

     Case 5:
        if rx>200 then rx=200
        if gx>200 then gx=200
        if bx>200 then bx=200
         For Nd = 2 To Led
             Reset Watchdog
             R = 255 : G = 255 : B = 255
             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
             Ndn = Nd - 1
             Rb_setcolor Ndn , Color(1)
             call time2
             Rb_send
             R = Rx : G = Gx : B = Bx
             Ndn = Nd - 2
             Rb_setcolor Ndn , Color(1)
             call time1
             Rb_send
         Next                                                        'call time1
         For Nd = Led -2 To 0 Step -1

           Reset Watchdog
           R = 255 : G = 255 : B = 255
             Rb_setcolor Nd , Color(1)
             call time2
             Rb_send
             Ndn = Nd + 1
             Rb_setcolor Ndn , Color(1)
             call time1
             Rb_send
             R = Rx : G = Gx : B = Bx
             Ndn = Nd + 2
             Rb_setcolor Ndn , Color(1)
            call time2
             Rb_send
         Next
     Case 6:

          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = 0 To Led
              Reset Watchdog
             Rb_setcolor Nd , Color(1)
             call time1
             Rb_send
         Next
          R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
         For Nd = Led To 0 Step -1
             Reset Watchdog
             Rb_setcolor Nd , Color(1)
             call time2
             Rb_send
         Next


     Case 7:
            For Nd = 0 To Led
                   Reset Watchdog
                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Rb_send
            Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
              Reset Watchdog
             Rb_shiftright 0 , Led
             call time2
             Rb_send
           Next
     Case 8:
           For Nd = 0 To Led
                     Reset Watchdog
                   Jj = Nd Mod 2
                   If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   Rb_send
           Next
           R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
                  Reset Watchdog
                Rb_shiftright 0 , Led
                call time2
                Rb_send
           Next
           For Nd = Led To 0 Step -1
                 Reset Watchdog
                Jj = Nd Mod 2
                If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                Rb_setcolor Nd , Color(1)
                call time1
                Rb_send
           Next
                 R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
                 Reset Watchdog
                Rb_shiftleft 0 , Led
                call time2
                Rb_send
           Next
     Case 9:
          If Chc = 0 Then
                 Waitus 100
                  Rb_clearcolors
                  If Tim1 > Led Then Tim1 = Led
               For Nd = 0 To Tim1
                         Reset Watchdog
                         Jj = Nd Mod 2
                        If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                         Rb_setcolor Nd , Color(1)
                        call time2
                          Reset Watchdog
                           call time2
                             Reset Watchdog
                         Rb_send
               Next
                   Chc = 1
          End If
              R = Rx : G = Gx : B = Bx

           For N = 1 To Led -1
                    Reset Watchdog
                   Rb_rotateright 0 , Led
               call time2
                 Reset Watchdog
            call time2
                             Reset Watchdog
                   Rb_send
           Next
     Case 10:
           If Chc = 0 Then
                     If Tim1 > Led Then Tim1 = Led
                  For Nd = 0 To Tim1
                               Reset Watchdog
                            Jj = Nd Mod 2
                         If Jj = 0 Then R = Rnd(rx) : G = Rnd(gx) : B = Rnd(bx)
                            Rb_setcolor Nd , Color(1)
                            Waitus 100
                            Rb_send
                  Next
                  Chc = 1
           End If
              R = Rx : G = Gx : B = Bx
           For N = 1 To Led -1
                 Reset Watchdog
                Rb_rotateright 0 , Led
                call time2
                Rb_send
           Next
     Case 11:
                   R = Rx : G = Gx : B = Bx
           For I = 0 To 254
                   Reset Watchdog
                   Nd = Rnd(led)
                   Rb_setcolor Nd , Color(1)
                   call time1
                   call time2
                   Rb_send
           Next
       Case 12:
               R = Rx : G = Gx : B = Bx

               For I = 0 To Led
                      Reset Watchdog
                      Nd = Rnd(led)
                      Rb_setcolor Nd , Color(1)
                      Rb_send
                      call time1
                      Rb_clearcolors
                      call time2
               Next

  End Select
Goto Main



sub chekm
    If Tim1 > 999 or tim1<1  Then Tim1 =1
    If Tim2 > 999 or tim1<2  Then Tim2 =1
end sub

sub time1
for  tt1=1 to tim1
Reset Watchdog
 waitms 1
next
end sub

sub time2
for  tt2=1 to tim2
Reset Watchdog
 waitms 1
next
end sub