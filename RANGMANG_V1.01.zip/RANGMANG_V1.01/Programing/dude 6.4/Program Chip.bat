@echo off
echo Identifying Chip...
avrdude -c usbasp -p m8 -B 4

if %errorlevel% == 0 (
    echo Chip identified at high speed. Programming at high speed...
    avrdude -c usbasp -p m8 -U flash:w:Rangmang_m8a.hex:i -U lfuse:w:0xBF:m -U hfuse:w:0xD9:m -B 4
) else (
    echo High speed identification failed. Trying mid speed...
    avrdude -c usbasp -p m8 -B 8
    if %errorlevel% == 0 (
        echo Chip identified at mid speed. Programming at mid speed...
        avrdude -c usbasp -p m8 -U flash:w:Rangmang_m8a.hex:i -U lfuse:w:0xBF:m -U hfuse:w:0xD9:m -B 8
    ) else (
        echo Mid speed identification failed. Trying low speed...
        avrdude -c usbasp -p m8 -B 32
        if %errorlevel% == 0 (
            echo Chip identified at low speed. Programming at low speed...
            avrdude -c usbasp -p m8 -U flash:w:Rangmang_m8a.hex:i -U lfuse:w:0xBF:m -U hfuse:w:0xD9:m -B 16
        ) else (
            echo All speed attempts failed. Please check connections and try again.
        )
    )
)

pause
